import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ---------- UI helpers (tema merah) ---------- */
const Box: React.FC<{alt?:boolean, children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row",justifyContent:"space-between",marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c,fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

/* ---------- Abjad Kabir & normalisasi ---------- */
const MAP: Record<string, number> = {
  "ا":1,"أ":1,"إ":1,"آ":1,"ء": 0,"ؤ":1,"ئ":1,
  "ب":2,"ج":3,"د":4,"ه":0,"ة": 0,"و": 0,"ز":7,"ح":8,"ط":9,"ي": 0,"ى":10,
  "ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
  "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000
};
type TaMode = "ha" | "ta";
function normChars(input:string, taMode:TaMode){
  const s = (input||"")
    .replace(/[^\u0600-\u06FF]/g,"")
    .replace(/[ًٌٍَُِْٰـۭۣۢۚۗۙۛۜ۟۠ۡۢۤۧۨ]/g,"");
  return [...s].map(ch=>{
    if (ch==="ة") return "";           // ⇦ selalu 0 (hapus), jangan tukar ke ه/ت
    if (ch==="أ"||ch==="إ"||ch==="آ") return "ا";
    if (ch==="ى") return "ي";
    return ch;
  });
}
const modWrap = (n:number, base:number)=>((Math.trunc(n)-1)%base+base)%base+1;

/* ---------- Pemetaan unsur huruf ringkas ---------- */
const H2U:Record<string,"Api"|"Angin"|"Air"|"Tanah"> = {
  "ا":"Api","أ":"Api","إ":"Api","آ":"Api","ء":"Api","ؤ":"Api","ئ":"Api",
  "ب":"Tanah","ج":"Api","د":"Tanah","ه":"Air","ة":"Air","و":"Air","ز":"Angin","ح":"Air","ط":"Api","ي":"Angin",
  "ك":"Angin","ل":"Tanah","م":"Air","ن":"Air","س":"Angin","ع":"Air","ف":"Angin","ص":"Tanah",
  "ق":"Angin","ر":"Api","ش":"Angin","ت":"Api","ث":"Angin","خ":"Air","ذ":"Angin","ض":"Tanah","ظ":"Angin","غ":"Air"
};
const colorByUnsur=(u?:string)=>u==="Api"?"#ff4d57":u==="Tanah"?"#b48b5a":u==="Angin"?"#77c0ff":u==="Air"?"#7bd1c9":"#e8e6e3";

/* ---------- Tafsir Posisi: awal/akhir/dominan ---------- */
function tafsirAwal(h:string){
  if(!h) return "—";
  const u = H2U[h]; 
  const base = {
    Api:"Pelopor berani; buka jalan baharu. Kawal gopoh & ego awal.",
    Angin:"Pembuka komunikasi/idea; pastikan fokus & susun prioriti.",
    Air:"Pembuka dengan empati; tetapkan sempadan emosi dari awal.",
    Tanah:"Pembuka tertib & praktikal; jangan terlalu kaku, beri ruang adaptasi."
  } as const;
  return `${h} — ${u}: ${base[u]}`;
}
function tafsirAkhir(h:string){
  if(!h) return "—";
  const u = H2U[h];
  const base = {
    Api:"Tutup dengan tegas & cepat; jaga adab ketika menutup.",
    Angin:"Tutup dengan makluman & hikmah; dokumentasi ringkas.",
    Air:"Tutup dengan damai; elak berlarutan kerana simpati.",
    Tanah:"Tutup kemas & lengkap; jangan tangguh yang kecil."
  } as const;
  return `${h} — ${u}: ${base[u]}`;
}
function tafsirDominan(h:string, n:number){
  if(!h) return "—";
  const u = H2U[h];
  const base = {
    Api:"Tema ujian: panas/tergesa. Latih sabar & wudhu’ sebelum bertindak.",
    Angin:"Tema ujian: berselerak/overthinking. Gunakan senarai & masa fokus.",
    Air:"Tema ujian: serapan emosi. Bina sempadan & rutin malam tenang.",
    Tanah:"Tema ujian: kaku/terbeban. Pecahkan tugasan & minta bantuan."
  } as const;
  return `${h} ×${n} — ${u}: ${base[u]}`;
}

/* ---------- Kad baharu ---------- */
const CardHurufPosisi: ExplainAdapter = {
  id: "huruf-posisi-detail",
  label: "Huruf — Tafsir Posisi (al-Būnī)",
  render() {
    const [nama, setNama] = useState<string>("");
    const [ibu, setIbu]   = useState<string>("");
    const [ta,  setTa]    = useState<TaMode>("ha");

    const H = useMemo(()=>normChars(nama, ta), [nama,ta]);
    const awal  = H[0] || "";
    const akhir = H[H.length-1] || "";
    const kira = H.reduce<Record<string,number>>((o,h)=> (o[h]=(o[h]||0)+1,o),{});
    const dom = Object.entries(kira).sort((a,b)=>b[1]-a[1])[0] || ["",0];

    // ringkasan angka kecil (tak ganggu kalkulator sedia ada)
    const jumlah = useMemo(()=>H.reduce((s,h)=>s+(MAP[h]||0),0),[H]);
    const baki30 = (jumlah%30)||30;
    const burj   = modWrap(jumlah,12);

    return (
      <Accordion title="Huruf — Tafsir Posisi (al-Būnī)">
        {/* Input */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input (Jawi/Arab)</Text>
          <Text style={{color:"#e8e6e3"}}>Nama Diri</Text>
          <TextInput value={nama} onChangeText={setNama} placeholder="cth: علي"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}}/>

          <Text style={{color:"#e8e6e3"}}>Nama Ibu (opsyenal)</Text>
          <TextInput value={ibu} onChangeText={setIbu} placeholder="cth: فاطمة"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}}/>

          {/* Kekalkan toggle, tapi jelaskan: ة kini 0 */}
          <View style={{flexDirection:"row"}}>
            <Chip label="ة → ه (0)" active={ta==="ha"} onPress={()=>setTa("ha")} color="#888" />
            <Chip label="ة → ت (0)" active={ta==="ta"} onPress={()=>setTa("ta")} color="#888" />
          </View>
        </Box>

        {/* Ringkasan kecil */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Ringkasan Angka (nama diri)</Text>
          <Row l="Jumlah" r={jumlah}/>
          <Row l="Baki 30" r={baki30}/>
          <Row l="Burj (mod12)" r={burj}/>
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Nilai ini dikira dalam kad ini sahaja untuk rujukan tafsir posisi.
          </Text>
        </Box>

        {/* Posisi */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Posisi Huruf — Penjelasan Khusus</Text>
          <Row l="Awal (pintu mula)" r={awal||"—"} c={colorByUnsur(H2U[awal])}/>
          <Text style={{color:"#c9c6c2",marginBottom:8}}>{tafsirAwal(awal)}</Text>

          <Row l="Akhir (pintu khātimah)" r={akhir||"—"} c={colorByUnsur(H2U[akhir])}/>
          <Text style={{color:"#c9c6c2",marginBottom:8}}>{tafsirAkhir(akhir)}</Text>

          <Row l="Dominan (paling banyak)" r={dom[0] ? `${dom[0]} ×${dom[1]}` : "—"} c={colorByUnsur(H2U[dom[0] as string])}/>
          <Text style={{color:"#c9c6c2"}}>{tafsirDominan(dom[0] as string, dom[1] as number)}</Text>

          <Text style={{color:"#9a9692",marginTop:8,fontSize:12}}>
            Nota: Posisi ialah **konteks makna huruf** (awal/akhir/dominan), bukan ramalan nasib.
          </Text>
        </Box>

        {/* Saran latihan unsur */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Saran Latihan (imbangi unsur)</Text>
          <Text style={{color:"#c9c6c2"}}>• Api: tunda reaksi 10s, wudhu’ sebelum balas mesej, rancang dahulu.</Text>
          <Text style={{color:"#c9c6c2"}}>• Angin: mod fokus (notifikasi senyap), senarai 3 perkara, mesej ringkas.</Text>
          <Text style={{color:"#c9c6c2"}}>• Air: had masa empati, jadual tidur konsisten, pelindung rumah (al-Baqarah).</Text>
          <Text style={{color:"#c9c6c2"}}>• Tanah: pecahkan tugasan mikro, KPI mingguan realistik, rehat bergerak 5–10m.</Text>
        </Box>

        <Text style={{color:"#9a9692",fontSize:12}}>
          Sumber inspirasi: tradisi Shams al-Maʿārif (al-Būnī) — disusun untuk muhasabah & adab; **tiada ritual**.
        </Text>
      </Accordion>
    );
  }
};

export default CardHurufPosisi;
