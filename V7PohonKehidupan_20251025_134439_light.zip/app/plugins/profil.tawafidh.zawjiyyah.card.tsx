import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ===== UI helpers (tema merah-gaming) ===== */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);
const Bullets:React.FC<{items:string[]}> = ({items}) => (
  <View style={{marginTop:6}}>
    {items.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>))}
  </View>
);

/* ===== Normalisasi & Abjad — ي ه و ء ة = 0 ===== */
type TaMode = "ha" | "ta";
function normalizeArabic(input:string, taMode:TaMode){
  const s = (input||"")
    .replace(/[^\u0600-\u06FF]/g,"")
    .replace(/[ًٌٍَُِْٰـۭۣۢۚۗۙۛۜ۟۠ۡۢۤۧۨ]/g,"");
  return [...s].map(ch=>{
    if (ch==="ة") return "";                // ⇦ ta marbuta sentiasa 0 (buang)
    if (ch==="أ"||ch==="إ"||ch==="آ") return "ا";
    if (ch==="ى") return "ي";
    if (ch==="ؤ") return "و";               // kekalkan normalize pembawa (nilai 0 di ABJAD)
    if (ch==="ئ") return "ي";
    return ch;
  }).join("");
}
const ABJAD: Record<string, number> = {
  "ا":1,"ب":2,"ج":3,"د":4,
  "ه":0,"و":0,"ز":7,"ح":8,"ط":9,"ي":0,
  "ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
  "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,
  "ء":0,"لا":31,"ة":0 // backup jika ada
};
function abjadSum(raw: string){
  if (!raw) return { total: 0, letters: [] as { ch: string; val: number }[] };
  let s = raw.trim();
  let total = 0;
  const letters: { ch: string; val: number }[] = [];
  s = s.replace(/لا/g, () => { total += 31; letters.push({ ch: "لا", val: 31 }); return ""; });
  for (const ch of s) {
    const val = ABJAD[ch] ?? 0;
    total += val;
    if (val) letters.push({ ch, val });
  }
  return { total, letters };
}
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

/* ===== Pemetaan tafsir (Shams-flavoured untuk rezeki & harmoni) ===== */
const UNSUR = [
  {k:1,n:"Api",   m:"Tenaga cari nafkah & keputusan pantas; kawal panas/ego agar rumahtangga tenang."},
  {k:2,n:"Angin", m:"Komunikasi & dagang; tetapkan fokus, jangan bertangguh mesej penting."},
  {k:3,n:"Air",   m:"Kasih & penjagaan; jaga sempadan emosi & rehat cukup."},
  {k:4,n:"Tanah", m:"Struktur nafkah & amanah; buat bajet & jadual keluarga."},
] as const;
const PLANET = [
  {k:1,n:"Zuhal",    m:"Ujian/hutang; kemas kewangan & disiplin belanja."},
  {k:2,n:"Musytari", m:"Luas rezeki/ilmu; perbanyak syukur & sedekah."},
  {k:3,n:"Marikh",   m:"Konflik; sejukkan reaksi & elak debat panas."},
  {k:4,n:"Matahari", m:"Kepimpinan rumah; elak pamer/ego, utamakan adab."},
  {k:5,n:"Zuhrah",   m:"Kasih, damai & persefahaman; raikan pasangan."},
  {k:6,n:"Utarid",   m:"Akal, tulisan & niaga; jelas perjanjian & senarai tugas."},
  {k:7,n:"Bulan",    m:"Rumah & memori; jaga suasana sakinah & tidur."},
] as const;
const BURJ = [
  {k:1,n:"Hamal",u:"Api",m:"Mulakan projek; jangan gopoh."},
  {k:2,n:"Thawr",u:"Tanah",m:"Kukuhkan harta & asas rumah."},
  {k:3,n:"Jawza",u:"Angin",m:"Komunikasi/niaga bersama."},
  {k:4,n:"Sartan",u:"Air",m:"Fokus rumah/anak & kasih."},
  {k:5,n:"Asad",u:"Api",m:"Karisma pasangan; kawal ego."},
  {k:6,n:"Sumbulah",u:"Tanah",m:"Tertib & khidmat harian."},
  {k:7,n:"Mizan",u:"Angin",m:"Keadilan & rundingan."},
  {k:8,n:"Aqrab",u:"Air",m:"Penyembuhan & rahsia rumah."},
  {k:9,n:"Qaws",u:"Api",m:"Safar/visi rezeki."},
  {k:10,n:"Jadi",u:"Tanah",m:"Taklif/kerja keras."},
  {k:11,n:"Dalw",u:"Angin",m:"Komuniti & jaringan."},
  {k:12,n:"Hut",u:"Air",m:"Penutupan baik & maaf."},
] as const;
const fasa30 = (b:number)=>{
  const v=(Math.trunc(b)||30);
  if(v<=10) return {t:"Pembukaan Rezeki", s:"Buka peluang, dialog pasangan, set KPI kecil."};
  if(v<=20) return {t:"Ujian Harmoni",   s:"Kawal emosi, audit bajet & jadual keluarga."};
  return {t:"Penutupan Kitaran", s:"Tutup hutang/isu; rombak peranan & rehatkan jiwa."};
};
const colorUnsur=(u?:string)=>u==="Api"?"#ff4d57":u==="Tanah"?"#b48b5a":u==="Angin"?"#77c0ff":u==="Air"?"#7bd1c9":"#e8e6e3";

/* ===== Mini-harmoni pasangan (skor adab) ===== */
function nearMod(a:number,b:number,mod:number){ const d=Math.abs(a-b)%mod; return Math.min(d,mod-d)<=1; }
function skorHarmoni(md4_a:number, md4_b:number, md7_a:number, md7_b:number, md12_a:number, md12_b:number, planetA:number, planetB:number){
  let s = 0;
  if (nearMod(md4_a, md4_b, 4)) s++;
  if (nearMod(md7_a, md7_b, 7)) s++;
  if (nearMod(md12_a, md12_b, 12)) s++;
  if ([2,5,7].includes(planetA) || [2,5,7].includes(planetB)) s++; // Musytari/Zuhrah/Bulan bantu serasi
  return Math.max(0, Math.min(s, 4));
}
function labelHarmoni(s:number){
  if (s>=4) return {t:"Serasi Kuat", d:"Serasi tinggi — jaga adab agar berkekalan."};
  if (s>=2) return {t:"Sederhana", d:"Boleh serasi dengan dialog & pembahagian tugas."};
  return {t:"Perlu Banyak Dialog", d:"Strukturkan kewangan, masa & komunikasi."};
}

/* ===== Kad: Tafsir pasangan / rezeki & harmoni ===== */
const CardTawafidhZawjiyyah: ExplainAdapter = {
  id: "profil-tawafidh-zawjiyyah",
  label: "Tafsir Pasangan / Rezeki & Harmoni — (Diri + Isteri + Anak)",
  render() {
    const [ta,setTa] = useState<TaMode>("ha");
    const [diri,setDiri] = useState("");
    const [isteri,setIsteri] = useState("");
    const [anak, setAnak] = useState<string[]>(Array.from({length:12},()=>"" ));

    const norm = (s:string)=>normalizeArabic(s,ta);
    const aDiri   = useMemo(()=>abjadSum(norm(diri)),   [diri,ta]);
    const aIsteri = useMemo(()=>abjadSum(norm(isteri)), [isteri,ta]);
    const aAnak   = useMemo(()=>anak.map(n=>abjadSum(norm(n))), [anak,ta]);

    const anakFilled = aAnak.filter(x=>x.total>0);
    const anakSum = anakFilled.reduce((s,x)=>s+x.total,0);

    const totalRumah = aDiri.total + aIsteri.total + anakSum;
    const baki       = (totalRumah % 30) || 30;

    const m4  = modWrap(totalRumah,4);
    const m7  = modWrap(totalRumah,7);
    const m12 = modWrap(totalRumah,12);

    const U = UNSUR.find(x=>x.k===m4)!;
    const P = PLANET.find(x=>x.k===m7)!;
    const B = BURJ.find(x=>x.k===m12)!;
    const F = fasa30(baki);

    // Harmoni pasangan (berdasarkan Diri vs Isteri sahaja)
    const d4 = modWrap(aDiri.total,4),  i4 = modWrap(aIsteri.total,4);
    const d7 = modWrap(aDiri.total,7),  i7 = modWrap(aIsteri.total,7);
    const d12= modWrap(aDiri.total,12), i12= modWrap(aIsteri.total,12);
    const pD = modWrap(aDiri.total,7),  pI  = modWrap(aIsteri.total,7);

    const skor = skorHarmoni(d4,i4,d7,i7,d12,i12,pD,pI);
    const H = labelHarmoni(skor);

    // Isyarat pola rezeki/harmoni (gabungan total Rumah)
    const flags:string[] = [];
    if (m4===2 && m7===6 && (m12===3||m12===11)) flags.push("Niaga/komunikasi keluarga sedang baik — formaliskan peranan & hasil.");
    if (m4===3 && m7===5 && (m12===4||m12===12)) flags.push("Rahmah & rumah mendominasi — jadikan rumah sumber sakinah & rehat.");
    if (m4===1 && m7===4 && (m12===1||m12===5)) flags.push("Kepimpinan nafkah tinggi — elak ego; buat keputusan selepas musyawarah.");
    if (m4===4 && m7===1 && (m12===2||m12===10)) flags.push("Taklif/hutang — audit kewangan, lunaskan ikut keutamaan & disiplin.");
    if (!flags.length) flags.push("Aliran serasi umum — kekalkan dialog mingguan & bajet keluarga.");

    const setAnakAt=(i:number,v:string)=>{
      setAnak(prev=> prev.map((x,idx)=> idx===i? v : x ));
    };
    const clearAll=()=>{
      setDiri(""); setIsteri(""); setAnak(Array.from({length:12},()=>"" ));
    };

    return (
      <Accordion title="Tafsir Pasangan / Rezeki & Harmoni — (Diri + Isteri + Anak)">
        {/* Input */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input (Jawi/Arab)</Text>
          <Text style={{color:"#e8e6e3"}}>Nama Diri</Text>
          <TextInput value={diri} onChangeText={setDiri} placeholder="cth: علي" placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}} />
          <Text style={{color:"#e8e6e3"}}>Nama Isteri</Text>
          <TextInput value={isteri} onChangeText={setIsteri} placeholder="cth: فاطمة" placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:10}} />

          <Text style={{color:"#e8e6e3",marginBottom:6}}>Anak (hingga 12 orang)</Text>
          <View style={{flexDirection:"row", flexWrap:"wrap"}}>
            {anak.map((v,idx)=>(
              <View key={idx} style={{width:"48%", marginRight:"2%", marginBottom:8}}>
                <Text style={{color:"#c9c6c2", fontSize:12}}>Anak {idx+1}</Text>
                <TextInput
                  value={v}
                  onChangeText={(t)=>setAnakAt(idx,t)}
                  placeholder="cth: محمد"
                  placeholderTextColor="#777"
                  style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8}}
                />
              </View>
            ))}
          </View>

          <Text style={{color:"#e8e6e3",marginTop:8, marginBottom:6}}>Ta marbūṭah (ة)</Text>
          <View style={{flexDirection:"row"}}>
            {/* Kekal toggle untuk UI; kedua-duanya kini (0) */}
            <Chip label="dikira ه (0)"  active={ta==="ha"} onPress={()=>setTa("ha")} color="#888" />
            <Chip label="dikira ت (0)"  active={ta==="ta"} onPress={()=>setTa("ta")} color="#888" />
          </View>

          <TouchableOpacity onPress={clearAll} style={{marginTop:8}}>
            <Text style={{color:"#9a9692",textDecorationLine:"underline"}}>Kosongkan semua</Text>
          </TouchableOpacity>
        </Box>

        {/* Ringkasan angka */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Ringkasan Kiraan</Text>
          <Row l="Jumlah Diri" r={aDiri.total}/>
          <Row l="Jumlah Isteri" r={aIsteri.total}/>
          <Row l={`Jumlah Anak (${anakFilled.length} orang)`} r={anakSum}/>
          <Row l="Jumlah Rumah (D+I+Anak)" r={totalRumah} c="#ff4d57"/>
          <Row l="Baki 30" r={baki} c="#ff4d57"/>
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Tafsir ini fokus: rezeki & harmoni rumah — gabungan Diri + Isteri + Anak.
          </Text>
        </Box>

        {/* Tafsir Rumah (gabungan) */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Tafsiran — Rumah Tangga</Text>
          <Row l="Unsur Dominan" r={U.n} c={colorUnsur(U.n)} />
          <Row l="Planet Naungan" r={P.n}/>
          <Row l="Burj Keluarga" r={`${B.n} (${B.u})`} />
          <Row l="Fasa (Baki 30)" r={F.t} />
          <Text style={{color:"#c9c6c2", marginTop:6}}>{U.m}</Text>
          <Text style={{color:"#c9c6c2"}}>{P.m}</Text>
          <Text style={{color:"#c9c6c2"}}>{B.m}</Text>
          <Text style={{color:"#c9c6c2"}}>• Saran fasa: {F.s}</Text>
        </Box>

        {/* Harmoni Pasangan (Diri vs Isteri) */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Indeks Harmoni (Pasangan)</Text>
          <Row l="Skor" r={`${H.t} (${skor}/4)`} c="#ffb3b8"/>
          <Text style={{color:"#c9c6c2"}}>{H.d}</Text>
          <Bullets items={[
            "Mod-4 rapat → serasi unsur & cara kerja.",
            "Mod-7 rapat → ritma emosi/rezeki selaras.",
            "Mod-12 rapat → tabiat berkitar hampir sama.",
            "Zuhrah/Musytari/Bulan pada salah satu → tambah keserasian."
          ]}/>
        </Box>

        {/* Isyarat Khas (pola) */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Isyarat Khas Rezeki & Harmoni</Text>
          {flags.map((t,i)=>(
            <Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>
          ))}
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Baca sebagai muhasabah/adab; **tiada ritual/azimat**. Fokus pada dialog, bajet & pembahagian peranan.
          </Text>
        </Box>
      </Accordion>
    );
  }
};

export default CardTawafidhZawjiyyah;
