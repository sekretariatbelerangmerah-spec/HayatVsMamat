import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/** ================= UI Helpers (tema gelap merah) ================= */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row:React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"})=>(
  <View style={{flexDirection:"row",justifyContent:"space-between",marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c,fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void}> = ({label,active,onPress})=>(
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?"#ff4d57":"transparent",
    borderWidth:1,borderColor:"#666",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

/** ================= Logik tempatan (stabil) =================
 * - Tanpa bergantung pada ../lib/abjad.hari (elak type mismatch)
 * - Huruf: ي ه و ء ة = 0
 * - Ligatur "لا" dikira 31
 * - toggle Ta marbūṭah dikekalkan untuk UI (kedua-dua = 0)
 */
type TaMode = "ha" | "ta";

const MAP0: Record<string, number> = {
  "ا":1,"أ":1,"إ":1,"آ":1,
  "ب":2,"ج":3,"د":4,
  "ه":0,"و":0,"ز":7,"ح":8,"ط":9,"ي":0,
  "ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
  "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,
  "ء":0,"ة":0,"لا":31
};

const STRIP=/[\u064B-\u065F\u0670\u06D6-\u06ED\u0610-\u061A\u0640\u200C\u200D\ufeff]/g;

/** Normalisasi selamat → sentiasa kembali STRING */
function normalizeJawi0(input: string, ta: TaMode): string {
  const raw = (input ?? "")
    .replace(/[^\u0600-\u06FF]/g,"") // kekalkan aksara Arab sahaja
    .replace(STRIP,"")
    .replace(/[أإآٱ]/g,"ا")
    .replace(/ى/g,"ي")
    .replace(/ؤ/g,"و")
    .replace(/ئ/g,"ي");
  // Ta marbuta: sentiasa 0 → buang
  return raw.replace(/ة/g,"");
}

/** Jumlah Abjad guna peta tempatan (termasuk "لا"=31) */
function sumAbjad0(s: string): number {
  if(!s) return 0;
  let t = 0;
  // kirakan ligatur "لا" dahulu
  s = s.replace(/لا/g, ()=>{ t += (MAP0["لا"]||0); return ""; });
  for(const ch of s) t += (MAP0[ch] ?? 0);
  return t;
}

/** mod wrap: 1..base */
const modWrap = (n:number, base:number)=>((Math.trunc(n)-1)%base+base)%base+1;

/** Data Planet 7 (setara struktur asal) */
const PLANET7: Array<{k:1|2|3|4|5|6|7; p:string; kuat:string; lemah:string; nota:string}> = [
  {k:1,p:"Zuhal",   kuat:"Sabtu",  lemah:"Isnin",  nota:"Sederhanakan jadual; elak janji besar."},
  {k:2,p:"Musytari",kuat:"Khamis", lemah:"Selasa", nota:"Fokus syukur; jangan over-commit."},
  {k:3,p:"Marikh",  kuat:"Selasa", lemah:"Jumaat", nota:"Jangan bertindak keras; lembutkan nada."},
  {k:4,p:"Matahari",kuat:"Ahad",   lemah:"Rabu",   nota:"Jaga ego; elak pamer & debat panjang."},
  {k:5,p:"Zuhrah",  kuat:"Jumaat", lemah:"Isnin",  nota:"Jaga hati/emosi; kurangkan drama."},
  {k:6,p:"Utarid",  kuat:"Rabu",   lemah:"Khamis", nota:"Jelas dokumen; elak mesej tergesa."},
  {k:7,p:"Bulan",   kuat:"Isnin",  lemah:"Sabtu",  nota:"Lindungi rumah & tidur; elak keputusan besar."},
];

/** ================= Kad ================= */
const CardHariLemahKuat: ExplainAdapter = {
  id: "profil-hari-lemah-kuat",
  label: "Hari Lemah & Hari Kuat (Nama + Ibu, mod-7)",
  render() {
    const [ta,setTa] = useState<TaMode>("ha");     // kekal hook/toggle
    const [nama,setNama] = useState("");
    const [ibu,setIbu]   = useState("");

    const total = useMemo(()=>{
      const a = sumAbjad0(normalizeJawi0(nama, ta));
      const b = sumAbjad0(normalizeJawi0(ibu,  ta));
      return a + b;
    },[nama,ibu,ta]);

    const m7 = modWrap(total,7);
    const P  = PLANET7.find(x=>x.k===m7)!;

    return (
      <Accordion title="Hari Lemah & Hari Kuat (Nama + Ibu, mod-7)">
        {/* Input */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input (Jawi/Arab)</Text>
          <Text style={{color:"#e8e6e3"}}>Nama Diri</Text>
          <TextInput value={nama} onChangeText={setNama} placeholder="cth: علي"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}} />
          <Text style={{color:"#e8e6e3"}}>Nama Ibu</Text>
          <TextInput value={ibu} onChangeText={setIbu} placeholder="cth: فاطمة"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}} />
          <Text style={{color:"#e8e6e3",marginBottom:6}}>Ta marbūṭah (ة)</Text>
          <View style={{flexDirection:"row"}}>
            {/* Kekal hook/toggle; kedua-dua (0) kerana ة dibuang */}
            <Chip label="dikira ه (0)"  active={ta==="ha"} onPress={()=>setTa("ha")} />
            <Chip label="dikira ت (0)"  active={ta==="ta"} onPress={()=>setTa("ta")} />
          </View>
        </Box>

        {/* Ringkasan */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Ringkasan</Text>
          <Row l="Jumlah Abjad (Diri + Ibu)" r={total} />
          <Row l="Mod-7 (Planet Diri)" r={`${P.p} (${m7})`} c="#ffb3b8" />
        </Box>

        {/* Hari */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Hari Kuat & Hari Lemah</Text>
          <Row l="Hari Kuat"  r={P.kuat}  c="#7bd1c9" />
          <Row l="Hari Lemah" r={P.lemah} c="#ff4d57" />
          <Text style={{color:"#c9c6c2",marginTop:6}}>
            Nota: Hari lemah = mudah terganggu emosi/urusan; <Text style={{fontWeight:"700"}}>bukan ramalan</Text>. Amalkan adab & perlindungan.
          </Text>
        </Box>

        {/* Saran adab */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Adab Praktikal</Text>
          <Text style={{color:"#c9c6c2",marginBottom:4}}>{`\u2022` } Hari kuat: urusan besar, musyawarah, sedekah.</Text>
          <Text style={{color:"#c9c6c2",marginBottom:4}}>{`\u2022` } Hari lemah: {P.nota}</Text>
          <Text style={{color:"#c9c6c2",marginBottom:4}}>{`\u2022` } Zikir perlindungan: Al-Ikhlāṣ, Al-Falaq, An-Nās; doa pagi-petang.</Text>
        </Box>

        <Text style={{color:"#9a9692",fontSize:12,marginTop:4}}>
          Disusun untuk muhasabah/adab — tiada ritual/azimat.
        </Text>
      </Accordion>
    );
  }
};

export default CardHariLemahKuat;
