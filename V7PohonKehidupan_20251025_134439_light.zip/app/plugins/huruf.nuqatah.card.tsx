import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ===== UI helpers (tema merah) ===== */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);
const BulletList:React.FC<{items:string[]}> = ({items}) => (
  <View style={{marginTop:6}}>
    {items.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>))}
  </View>
);

/* ===== Normalisasi huruf & peta unsur (neutralize ي ه و ء ة = 0) ===== */
type TaMode = "ha" | "ta";
function normChars(input:string, taMode:TaMode){
  const s = (input||"")
    .replace(/[^\u0600-\u06FF]/g,"")
    .replace(/[ًٌٍَُِْٰـۭۣۢۚۗۙۛۜ۟۠ۡۢۤۧۨ]/g,"");
  return [...s].map(ch=>{
    if (["ي","ه","و","ء","ة"].includes(ch)) return ""; // 0 kosong
    if (ch==="أ"||ch==="إ"||ch==="آ") return "ا";
    if (ch==="ى") return "ي";
    return ch;
  });
}

// Kumpulan titik (Ibn 'Arabi perspective)
const TOP_DOTS = new Set(["ف","ق","ث","ظ","خ","ز","غ","ض","ذ","ظ"]);
const BTM_DOTS = new Set(["ب","ي","ن","ت"]);
const NO_DOTS  = new Set(["ا","ح","د","ر","س","ص","ط","ع","ل","م","ك","ج","ش"]);

// Peta unsur huruf (al-Būnī — ي ه و ء ة = 0, abaikan)
const HURUF_UNSUR:Record<string,"Api"|"Angin"|"Air"|"Tanah"> = {
  "ا":"Api","أ":"Api","إ":"Api","آ":"Api",
  "ب":"Tanah","ج":"Api","د":"Tanah","ز":"Angin","ح":"Air","ط":"Api",
  "ك":"Angin","ل":"Tanah","م":"Air","ن":"Air","س":"Angin","ع":"Air","ف":"Angin","ص":"Tanah",
  "ق":"Angin","ر":"Api","ش":"Angin","ت":"Api","ث":"Angin","خ":"Air","ذ":"Angin","ض":"Tanah","ظ":"Angin","غ":"Air"
};
const UNSUR_LIST = ["Api","Angin","Air","Tanah"] as const;
const colorByUnsur=(u?:string)=>u==="Api"?"#ff4d57":u==="Tanah"?"#b48b5a":u==="Angin"?"#77c0ff":u==="Air"?"#7bd1c9":"#e8e6e3";

/* ===== Tafsir gabungan ===== */
const tafsirUnsurLemah: Record<typeof UNSUR_LIST[number], string[]> = {
  Api:   ["Kurang semangat & keberanian.","Latih keputusan kecil harian.","Zikir al-Qahhār; sujud malam."],
  Angin: ["Kurang komunikasi/fleksibiliti.","Tulis nota & ringkaskan mesej.","Zikir al-Wadūd; adab salam."],
  Air:   ["Kurang empati/kelembutan.","Time-box emosi & dengar aktif.","Zikir al-Raḥmān; jaga wudu’."],
  Tanah: ["Kurang struktur/istiqāmah.","Pecah tugasan mikro; jadual.","Zikir al-Ṣabūr; rehat berjadual."]
};

/* ===== Komponen Kad ===== */
const CardNuqatah: ExplainAdapter = {
  id: "huruf-nuqatah",
  label: "Huruf — Titik Lemah & Sirr (al-Būnī × Ibn ʿArabī)",
  render() {
    const [nama,setNama] = useState("");
    const [ta,setTa]     = useState<TaMode>("ha");

    const H = useMemo(()=>normChars(nama,ta),[nama,ta]);

    // Kiraan titik
    const counts = useMemo(()=>{
      let top=0, btm=0, none=0;
      for (const h of H) {
        if (BTM_DOTS.has(h)) btm++;
        else if (TOP_DOTS.has(h)) top++;
        else if (NO_DOTS.has(h)) none++;
        else none++;
      }
      return {top, btm, none, total:H.length};
    },[H]);

    // Kiraan unsur
    const unsurCount = useMemo(()=>{
      const u = {Api:0,Angin:0,Air:0,Tanah:0} as Record<typeof UNSUR_LIST[number],number>;
      for (const h of H) {
        const k = HURUF_UNSUR[h];
        if (k) u[k] += 1;
      }
      return u;
    },[H]);

    const unsurTiada = useMemo(()=>UNSUR_LIST.filter(u=>unsurCount[u]===0),[unsurCount]);
    const unsMax = Math.max(...UNSUR_LIST.map(u=>unsurCount[u]));
    const unsMin = Math.min(...UNSUR_LIST.map(u=>unsurCount[u]));
    const unsurDominan = UNSUR_LIST.filter(u=>unsurCount[u]===unsMax);
    const unsurLemah   = UNSUR_LIST.filter(u=>unsurCount[u]===unsMin);

    return (
      <Accordion title="Huruf — Titik Lemah & Sirr (al-Būnī × Ibn ʿArabī)">
        {/* Input */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input (Jawi/Arab)</Text>
          <TextInput
            value={nama}
            onChangeText={setNama}
            placeholder="cth: علي / فاطمة"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8}}
          />
          <View style={{flexDirection:"row", marginTop:8}}>
            <Chip label="ة → ه (0)" active={ta==="ha"} onPress={()=>setTa("ha")} color="#888" />
            <Chip label="ة → ت (0)" active={ta==="ta"} onPress={()=>setTa("ta")} color="#888" />
          </View>
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Nota: ي ه و ء ة kini dikira 0 (kosong); hanya huruf lain aktif.
          </Text>
        </Box>

        {/* Ringkasan Titik */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Jejak Titik (Sirr al-Nuqṭah — Ibn ʿArabī)</Text>
          <Row l="Titik atas"  r={counts.top}/>
          <Row l="Titik bawah" r={counts.btm}/>
          <Row l="Tiada titik" r={counts.none}/>
          <Row l="Jumlah huruf" r={counts.total}/>
          <BulletList items={[
            ...(counts.top  ? ["Titik atas menonjol → potensi kepimpinan; kawal ego."] : []),
            ...(counts.btm  ? ["Titik bawah menonjol → potensi batin/empati; kawal emosi."] : []),
            ...(counts.none ? ["Huruf tanpa titik → grounding; tambah tafakkur."] : [])
          ]}/>
          {!counts.total && <Text style={{color:"#777"}}>Taip nama untuk lihat tafsiran.</Text>}
        </Box>

        {/* Unsur (al-Būnī) */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Unsur Huruf (al-Būnī)</Text>
          <View style={{flexDirection:"row", flexWrap:"wrap", gap:8}}>
            {UNSUR_LIST.map(u=>(
              <View key={u} style={{paddingVertical:6,paddingHorizontal:10,borderRadius:8,borderWidth:1,borderColor:"#2a0e14",backgroundColor:"#12090b",marginRight:8,marginBottom:8}}>
                <Text style={{color:colorByUnsur(u),fontWeight:"700"}}>{u}</Text>
                <Text style={{color:"#c9c6c2"}}>{unsurCount[u]} huruf</Text>
              </View>
            ))}
          </View>

          <Text style={{color:"#e8e6e3",fontWeight:"700",marginTop:6}}>Unsur Tiada</Text>
          <Text style={{color:unsurTiada.length?"#ffb3b8":"#9a9692"}}>
            {unsurTiada.length?unsurTiada.join(", "):"— lengkap —"}
          </Text>
          {unsurTiada.length>0 && unsurTiada.map(u=>(
            <View key={u} style={{marginTop:6}}>
              <Text style={{color:colorByUnsur(u),fontWeight:"700"}}>• {u}</Text>
              <BulletList items={tafsirUnsurLemah[u]} />
            </View>
          ))}

          <View style={{marginTop:10}}>
            <Text style={{color:"#e8e6e3",fontWeight:"700"}}>Dominan (relatif)</Text>
            <Text style={{color:"#c9c6c2"}}>{unsurDominan.join(", ")||"—"}</Text>
            <Text style={{color:"#e8e6e3",fontWeight:"700",marginTop:6}}>Lemah (relatif)</Text>
            <Text style={{color:"#c9c6c2"}}>{unsurLemah.join(", ")||"—"}</Text>
          </View>
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Saran Tazkiyah (ringkas)</Text>
          <BulletList items={[
            "Api → tunda reaksi 10s, rancang sebelum balas.",
            "Angin → mod fokus, mesej ringkas, senarai 3 perkara.",
            "Air → sempadan empati, tidur konsisten, pelindung rumah.",
            "Tanah → pecahkan tugasan, KPI mingguan, rehat bergerak."
          ]}/>
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Baca sebagai muhasabah/adab — bukan ramalan.
          </Text>
        </Box>

        <Text style={{color:"#9a9692",fontSize:12}}>
          Sumber: Shams al-Maʿārif (al-Būnī) & Futūḥāt (Ibn ʿArabī), versi selamat moden.
        </Text>
      </Accordion>
    );
  }
};

export default CardNuqatah;
