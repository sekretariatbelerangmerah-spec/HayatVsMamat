import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

const MIZAJ = {
  1: {
    nama: "Api (Ḥār Yābis)",
    kekuatan: ["Berani, berdaya mula", "Pantas membuat keputusan"],
    risiko: ["Panas baran, cepat bosan", "Cenderung dominan/ego"],
    imbangan: ["Sejukkan dengan Air (empati)", "Jadual rehat & wudhu’ kerap"],
  },
  2: {
    nama: "Angin (Ḥār Rāṭib)",
    kekuatan: ["Kreatif, komunikatif", "Fleksibel & cepat belajar"],
    risiko: ["Gelisah, kurang konsisten", "Terlalu banyak lintasan"],
    imbangan: ["Tetapkan rutin tanah (to-do)", "Dokumentasi & semak semula"],
  },
  3: {
    nama: "Air (Bārid Rāṭib)",
    kekuatan: ["Empati & penyembuh", "Mudah menyesuaikan"],
    risiko: ["Serapan emosi, sukar tegas", "Terlalu mengikut rasa"],
    imbangan: ["Sempadan jelas (boundaries)", "Latih keputusan kecil harian"],
  },
  4: {
    nama: "Tanah (Bārid Yābis)",
    kekuatan: ["Stabil, amanah, tekun", "Kemas & praktikal"],
    risiko: ["Lambat, rigid", "Sukar berubah"],
    imbangan: ["Suntik Angin (idea/variasi)", "Tetapkan checkpoint fleksibel"],
  },
} as const;

const Bar = ({label, val}:{label:string; val:number}) => (
  <View style={{marginBottom:6}}>
    <Text style={{color:"#e8e6e3", marginBottom:2}}>{label}</Text>
    <View style={{height:8, backgroundColor:"#2a0e14", borderRadius:6}}>
      <View style={{height:8, width:`${Math.min(100, Math.max(0,val))}%`, backgroundColor:"#ff4d57", borderRadius:6}} />
    </View>
  </View>
);

const Box: React.FC<{children:any}> = ({children}) => (
  <View style={{backgroundColor:"#14090b", borderRadius:12, padding:12, marginBottom:10, borderWidth:1, borderColor:"#2a0e14"}}>
    {children}
  </View>
);

const ProfilMizajCard: ExplainAdapter = {
  id: "mizaj",
  label: "Profil — Mizāj (Temperamen Unsur)",
  render({ aDiri = 0, aKeluarga = 0 }: Input) {
    const m4d = modWrap(aDiri, 4);
    const m4k = modWrap(aKeluarga, 4);
    const dom = MIZAJ[m4d as 1|2|3|4];
    // skor ringkas: diri dominan 70, keluarga 30 → “campuran” visual
    const mixScore = (key:number) => {
      const is = (key === m4d ? 70 : 0) + (key === m4k ? 30 : 0);
      return is;
    };
    return (
      <Accordion title="Profil — Mizāj (Temperamen Unsur)">
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:8}}>Dominan: {dom.nama}</Text>
          <Bar label="Api"   val={mixScore(1)} />
          <Bar label="Angin" val={mixScore(2)} />
          <Bar label="Air"   val={mixScore(3)} />
          <Bar label="Tanah" val={mixScore(4)} />
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Nota: Campuran 70% (diri) + 30% (keluarga) sebagai panduan visual.
          </Text>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Kekuatan</Text>
          {dom.kekuatan.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Risiko</Text>
          {dom.risiko.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Cadangan Imbangan</Text>
          {dom.imbangan.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
        </Box>
      </Accordion>
    );
  }
};
export default ProfilMizajCard;
