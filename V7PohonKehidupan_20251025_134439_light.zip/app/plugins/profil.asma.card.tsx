import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/**
 * Tanasub Sifat: 99 Nama — Akhlak & Adab
 * --------------------------------------
 * Berdasarkan padanan klasik: Planet → Unsur → Sifat dominan.
 * Tafsiran fokus pada akhlak & adab, bukan amalan zikir.
 */

const C = { bg:"#14090b", sub:"#0f0a0b", border:"#2a0e14", text:"#e8e6e3", accent:"#ff4d57", dim:"#9a9692" };
const Box:React.FC<{children:any,alt?:boolean}> = ({children,alt})=>(
  <View style={{
    backgroundColor:alt?C.sub:C.bg,
    borderRadius:12,padding:12,marginBottom:10,
    borderWidth:1,borderColor:C.border
  }}>{children}</View>
);
const Row:React.FC<{l:string;r:string|number;c?:string}> = ({l,r,c=C.text})=>(
  <View style={{flexDirection:"row",justifyContent:"space-between",marginBottom:6}}>
    <Text style={{color:C.text,opacity:.85}}>{l}</Text>
    <Text style={{color:c,fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

// Planet–Asma–Akhlak mapping
const DATA = [
  {
    planet:"Zuhal (Saturnus)",
    asma:"الصبور – As-Sabūr",
    sifat:"Sabar, tenang menghadapi ujian; tidak terburu dalam keputusan.",
    adab:"Jangan cepat marah; hormati masa & proses; jadilah penenang dalam pasukan."
  },
  {
    planet:"Musytari (Jupiter)",
    asma:"الوهاب – Al-Wahhāb",
    sifat:"Dermawan, suka berkongsi ilmu & peluang.",
    adab:"Jaga ikhlas dalam memberi; jangan mengharap balasan manusia."
  },
  {
    planet:"Marikh (Marikh)",
    asma:"الجبار – Al-Jabbār",
    sifat:"Kuat, berani menegakkan kebenaran.",
    adab:"Gunakan kekuatan untuk melindung, bukan menindas; kawal kemarahan."
  },
  {
    planet:"Matahari (Shams)",
    asma:"النور – An-Nūr",
    sifat:"Karisma, inspirasi & kepimpinan.",
    adab:"Jangan riya’; pancarkan kebaikan tanpa menjatuhkan orang lain."
  },
  {
    planet:"Zuhrah (Venus)",
    asma:"الودود – Al-Wadūd",
    sifat:"Kasih sayang, harmoni & daya tarik lembut.",
    adab:"Bersikap penyayang tanpa melampau; jaga kesucian niat cinta."
  },
  {
    planet:"Utarid (Merkuri)",
    asma:"الحكيم – Al-Hakīm",
    sifat:"Bijaksana, fasih & pemikir strategik.",
    adab:"Gunakan lidah & pena untuk maslahat, bukan fitnah."
  },
  {
    planet:"Bulan (Qamar)",
    asma:"اللطيف – Al-Latīf",
    sifat:"Halus rasa, mudah tersentuh & memahami orang.",
    adab:"Gunakan empati dengan seimbang; jangan terlalu memendam."
  }
];

const ELEMENTS = {
  "Api":{asma:"العزيز – Al-ʿAzīz",sifat:"Ketegasan & kehormatan.",adab:"Tegas tapi lembut; jangan sombong."},
  "Angin":{asma:"السميع – As-Samīʿ",sifat:"Kepekaan mendengar & komunikasi.",adab:"Dengar dahulu sebelum menilai."},
  "Air":{asma:"الرحمن – Ar-Raḥmān",sifat:"Kasih, tenang & mudah memaafkan.",adab:"Sabar & lembut dengan semua makhluk."},
  "Tanah":{asma:"الحق – Al-Ḥaqq",sifat:"Keteguhan & amanah.",adab:"Pegang janji & jujur dalam urusan."}
};

const ProfilAsmaCard:ExplainAdapter = {
  id:"asma",
  label:"Tanasub Sifat — 99 Nama & Akhlak",
  render({ planet="", unsur="" }:Input){
    const P = DATA.find(d=>planet.includes(d.planet.split(" ")[0])) || DATA[Math.floor(Math.random()*7)];
    const U = ELEMENTS[unsur as keyof typeof ELEMENTS] || ELEMENTS["Tanah"];
    return (
      <Accordion title="Tanasub Sifat — 99 Nama & Akhlak">
        <Box>
          <Row l="Planet Dominan" r={planet||P.planet}/>
          <Row l="Unsur Dominan" r={unsur||"—"}/>
          <Text style={{color:C.dim,marginTop:6,fontSize:12}}>Padanan sifat akhlak menurut 99 Nama Allah.</Text>
        </Box>
        <Box>
          <Text style={{color:C.text,fontWeight:"800",marginBottom:6}}>Sifat Planet</Text>
          <Text style={{color:C.accent,fontWeight:"700",marginBottom:4}}>{P.asma}</Text>
          <Text style={{color:"#c9c6c2",marginBottom:4}}>{P.sifat}</Text>
          <Text style={{color:"#c9c6c2"}}>{P.adab}</Text>
        </Box>
        <Box alt>
          <Text style={{color:C.text,fontWeight:"800",marginBottom:6}}>Sifat Unsur</Text>
          <Text style={{color:C.accent,fontWeight:"700",marginBottom:4}}>{U.asma}</Text>
          <Text style={{color:"#c9c6c2",marginBottom:4}}>{U.sifat}</Text>
          <Text style={{color:"#c9c6c2"}}>{U.adab}</Text>
        </Box>
        <Box>
          <Text style={{color:C.text,fontWeight:"800",marginBottom:6}}>Panduan Amalan Harian</Text>
          <Text style={{color:"#c9c6c2"}}>• Mulakan hari dengan doa: “اللهم اجعلني من أحسن خلقك خلقاً”.</Text>
          <Text style={{color:"#c9c6c2"}}>• Latih akhlak selaras dengan planet & unsur diri.</Text>
          <Text style={{color:"#c9c6c2"}}>• Jauhkan niat memperalat nama Allah untuk faedah duniawi.</Text>
        </Box>
        <Text style={{color:C.dim,marginTop:8,fontSize:12}}>
          Tafsiran berdasarkan karya al-Būnī, al-Ghazālī (“al-Maqṣad al-Asnā”), dan Shams al-Maʿārif;
          tujuan: pembinaan akhlak, bukan ritualisme.
        </Text>
      </Accordion>
    );
  }
};
export default ProfilAsmaCard;
