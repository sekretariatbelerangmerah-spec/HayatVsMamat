import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import { getHijriDay } from "../lib/hijriUtil";
import type { ExplainAdapter, Input } from "../adapters/types";

// Simple theme bits
const Box: React.FC<{children: any, alt?: boolean}> = ({children, alt}) => (
  <View style={{
    backgroundColor: alt ? "#0f1115" : "#141016",
    borderRadius: 12, padding: 12, marginBottom: 10,
    borderWidth: 1, borderColor: alt ? "#2a2833" : "#2a1820"
  }}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#bcb9b6"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

// 28 lunar mansions (manāzil) — Arabic name, Latin, short gloss
const MANSIONS = [
  ["الشَّرَطان","Ash-Sharṭān","Permulaan niat & ikatan."],
  ["البُطَيْن","Al-Buṭayn","Pengumpulan kecil, teliti."],
  ["الثُّرَيَّا","Ath-Thurayyā","Cahaya, kecerlangan, ilmu."],
  ["الدَّبَرَان","Ad-Dabarān","Mengekor; sabar & tekun."],
  ["الهَقْعَة","Al-Haqqaʿh","Ketetapan, fokus asas."],
  ["الهَنَعَة","Al-Hanaʿh","Lentur/rujuk; elak keras."],
  ["الذِّرَاع","Adh-Dhirāʿ","Tangan/ikhtiar, usaha nyata."],
  ["النَّثْرَة","An-Nathrah","Serak; bersih & susun balik."],
  ["الطَّرْف","Aṭ-Ṭarf","Pandangan; kawal ego."],
  ["الجَبْهَة","Al-Jabhah","Dahi/izzah; adab kuasa."],
  ["الزُّبْرَة","Az-Zubrah","Kekuatan; jangan zalim."],
  ["الصَّرْفَة","Aṣ-Ṣarfah","Pusing haluan; hijrah."],
  ["العَوَّاء","Al-ʿAwwā’","Panggilan; respons cepat."],
  ["السِّمَاك","As-Simāk","Pengikat; kukuhkan janji."],
  ["الغَفْر","Al-Ghafar","Tutup aib; istighfar."],
  ["الزُّبَانِي","Az-Zubānī","Cakar; tegas adil."],
  ["الإِكْلِيل","Al-Iklīl","Mahkota; pemaknaan niat."],
  ["القَلْب","Al-Qalb","Hati; lembutkan emosi."],
  ["الشَّوْلَة","Ash-Shawlah","Duri; jaga batas."],
  ["النَّعَائِم","An-Naʿāʾim","Kelembutan & keselesaan."],
  ["البَلْدَة","Al-Baldah","Rehat, neutral; muhasabah."],
  ["سَعْدُ الذَّابِح","Saʿd adh-Dhābiḥ","Korban; lepaskan beban."],
  ["سَعْدُ بُلَع","Saʿd Bulaʿ","Serap/terima; ilmu & zikir."],
  ["سَعْدُ السُّعُود","Saʿd as-Suʿūd","Nasib baik; syukur & adab."],
  ["سَعْدُ الأخْبِيَة","Saʿd al-Akhbiyah","Kem; bina jaringan."],
  ["الفَرْغُ المُقَدَّم","Al-Farg al-Muqaddam","Tumpah awal; tutur amanah."],
  ["الفَرْغُ المُؤَخَّر","Al-Farg al-Mu’akhkhar","Tumpah akhir; tutup kemas."],
  ["الرِّشَا","Ar-Rishā’","Tali timba; raih bantuan."],
];

const ProfilManazilCard: ExplainAdapter = {
  id: "profil-manazil",
  label: "Profil — Manāzil al-Qamar (28 Rumah Bulan)",
  render(input: Input) {
    const tawafiq = (input.aDiri||0) + (input.aIbu||0) + (input.aIsteri||0) + (input.aAnakJumlah||0);
    const USE_REAL_HIJRI = true;
    const hijriDay = (USE_REAL_HIJRI
      ? getHijriDay()                                     // hari Hijri sebenar
      : ((((tawafiq % 30) + 30) % 30) || 30)               // guna baki30 dari tawafiq
    );                 // 1..30 (real Hijri)
    const baki30   = ((tawafiq % 30) + 30) % 30 || 30;

    // Map 1..30 -> 1..28 (manāzil). Common mapping: 29→1, 30→2
    const to28 = (d:number)=> d<=28 ? d : (d===29 ? 1 : 2);
    const idx  = to28(hijriDay) - 1;
    const [arab, latin, gloss] = MANSIONS[idx];

    return (
      <Accordion title="Profil — Manāzil al-Qamar (28 Rumah Bulan)">
        <Box>
          <Row l="Tawāfiq (Jumlah Abjad)" r={tawafiq} c="#ff4d57"/>
          <Row l="Baki 30 (proksi hari lunar)" r={baki30} c="#ff4d57"/>
          <Row l="Hari Manzil (1–28)" r={to28(hijriDay)} c="#ffb84d"/>
          <Text style={{color:"#8f8b88", marginTop:6, fontSize:12}}>
            Nota: App gunakan hari Hijri sebenar (auto). Modul ini ringkas untuk rujukan simbolik manāzil.
          </Text>
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Nama & Sifat</Text>
          <Row l="Nama Arab" r={arab}/>
          <Row l="Latin" r={latin}/>
          <Text style={{color:"#cfcac6", marginTop:6}}>{gloss}</Text>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Nasihat Adab</Text>
          <Text style={{color:"#cfcac6"}}>
            Rehatkan diri; jaga tidur & diet. Elakkan keterlanjuran kata; kemaskan janji & hutang.
          </Text>
          <Text style={{color:"#8f8b88", marginTop:6, fontSize:12}}>
            Penjelasan ini bersifat simbolik/edukasi berasaskan tradisi manāzil; elakkan menisbahkan kepastian nasib.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ProfilManazilCard;
