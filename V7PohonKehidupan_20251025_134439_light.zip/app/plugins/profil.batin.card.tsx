import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

// --- util kecil
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

// ——— Dimensi BATIN (rohani) ———
const UNSUR_BATIN = [
  { k:1, n:"Api — Ruh Jihad",    m:"Tenaga pembersihan melalui ujian panas; jaga ego & niat, istiqamah dalam taubat." },
  { k:2, n:"Angin — Ruh Ilham",  m:"Lintasan & mimpi kuat; disiplinkan zikir/adab ilmu supaya ilham tidak melayah." },
  { k:3, n:"Air — Ruh Rahmah",   m:"Empati & penyembuh; jaga sempadan hati, elak larut dalam duka orang." },
  { k:4, n:"Tanah — Ruh Amanah", m:"Sabar & stabil; beban tanggungjawab jadi jalan kenaikan maqam." },
] as const;

const PLANET_BATIN = [
  { k:1, n:"Zuhal — Guru Ujian",      m:"Tarbiah melalui sempit/sakit; sabar & tertib melahirkan hikmah." },
  { k:2, n:"Musytari — Futuhat Ilmu", m:"Pintu kefahaman hakikat; muliakan adab & khidmat." },
  { k:3, n:"Marikh — Pejuang Nafs",   m:"Mujahadah; laras kemarahan, elak takabbur." },
  { k:4, n:"Matahari — Nafas Nur",    m:"Benih kepimpinan rohani; kawal pamer & ujub." },
  { k:5, n:"Zuhrah — Sakinah",        m:"Cinta yang menyucikan; rawat hati dengan kasih & ihsan." },
  { k:6, n:"Utarid — Kalam Hikmah",   m:"Lidah/pena sebagai amanah; tulis & bercakap dengan niat yang suci." },
  { k:7, n:"Bulan — Cermin Hati",     m:"Kasyaf & intuisi; perlu hijab/wiqāyah (wirid pelindung)." },
] as const;

const BURJ_BATIN = [
  { k:1,  n:"Hamal — Permulaan Maqam",   u:"Api",   m:"Didik nafsu ammārah; kuatkan asas ibadah." },
  { k:2,  n:"Thawr — Pengukuhan Iman",   u:"Tanah", m:"Bina rutin & istiqamah." },
  { k:3,  n:"Jawza — Dakwah & Ilham",    u:"Angin", m:"Saring lintasan; ikut guru/tertib." },
  { k:4,  n:"Sartan — Kasih & Penjagaan",u:"Air",   m:"Rawat emosi/keluarga sebagai ibadah." },
  { k:5,  n:"Asad — Nur Kepimpinan",     u:"Api",   m:"Pimpin dengan tawaduk; elak ujub." },
  { k:6,  n:"Sumbulah — Suluk Tertib",   u:"Tanah", m:"Perhalus amal; jaga kebersihan lahir/batin." },
  { k:7,  n:"Mizan — Tawazun Niat",      u:"Angin", m:"Adil terhadap diri & orang lain." },
  { k:8,  n:"Aqrab — Transformasi Sirr", u:"Air",   m:"Mujahadah mendalam; rahsia & taubat." },
  { k:9,  n:"Qaws — Safar Rohani",       u:"Api",   m:"Melihat jauh; jangan lari dari amanah." },
  { k:10, n:"Jadi — Tanggungjawab Maqam",u:"Tanah", m:"Sabar panjang; redha dalam tugas berat." },
  { k:11, n:"Dalw — Khidmat Ummah",      u:"Angin", m:"Inovasi bermanfaat; reformasi akhlak." },
  { k:12, n:"Hut — Penyatuan & Fana’",   u:"Air",   m:"Kasih & tenang; kembali kepada Nur." },
] as const;

const bakiMaksudBatin = (b:number)=>{
  const v = Math.trunc(b)||30;
  if (v>=1 && v<=10)  return "Fasa pembukaan: semangat & rezeki rohani terbuka — tambah syukur & zikir.";
  if (v>=11 && v<=20) return "Fasa ujian: penyakit/konflik batin — perbanyak istighfar & muraqabah.";
  return "Fasa kematangan: ketenangan & hikmah — mantapkan adab & khidmat.";
};

const Box: React.FC<{children:any}> = ({children}) => (
  <View style={{backgroundColor:"#120a12", borderRadius:12, padding:12, marginBottom:10, borderWidth:1, borderColor:"#2b1233"}}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#f2e8ff"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#f2e8ff", opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

/** PROFIL HAYAT (BATIN) — tafsiran rohani berasaskan jumlah abjad (tanpa bulan) */
const ProfilBatinCard: ExplainAdapter = {
  id: "profil-batin",
  label: "Penjelasan — Profil Hayat (Batin/Rohani)",
  render(input: Input) {
    const totalTawafiq = (input.aDiri||0) + (input.aIbu||0) + (input.aIsteri||0) + (input.aAnakJumlah||0);
    const m4  = modWrap(totalTawafiq,4);
    const m7  = modWrap(totalTawafiq,7);
    const m12 = modWrap(totalTawafiq,12);
    const baki = (totalTawafiq % 30) || 30;

    const U = UNSUR_BATIN.find(x=>x.k===m4)!;
    const P = PLANET_BATIN.find(x=>x.k===m7)!;
    const B = BURJ_BATIN.find(x=>x.k===m12)!;

    return (
      <Accordion title="Penjelasan — Profil Hayat (Batin/Rohani)">
        <Box>
          <Row l="Tawāfiq (Jumlah Abjad)" r={totalTawafiq} c="#e3b341" />
          <Row l="Baki 30 (Rohani)" r={baki} c="#e3b341" />
        </Box>

        <Box>
          <Text style={{color:"#f2e8ff", fontWeight:"800", marginBottom:8}}>Unsur — Arah Jiwa</Text>
          <Row l="Unsur Batin" r={U.n} />
          <Text style={{color:"#e0d7f8"}}>{U.m}</Text>
        </Box>

        <Box>
          <Text style={{color:"#f2e8ff", fontWeight:"800", marginBottom:8}}>Planet — Takdir Latihan</Text>
          <Row l="Planet Batin" r={P.n} />
          <Text style={{color:"#e0d7f8"}}>{P.m}</Text>
        </Box>

        <Box>
          <Text style={{color:"#f2e8ff", fontWeight:"800", marginBottom:8}}>Burj — Jalan Suluk</Text>
          <Row l="Burj Batin" r={`${B.n} (${B.u})`} />
          <Text style={{color:"#e0d7f8"}}>{B.m}</Text>
        </Box>

        <Box>
          <Text style={{color:"#f2e8ff", fontWeight:"800", marginBottom:8}}>Fasa Baki 30</Text>
          <Text style={{color:"#f2e8ff"}}>{baki} — {bakiMaksudBatin(baki)}</Text>
          <Text style={{color:"#cbbde3", marginTop:6, fontSize:12}}>
            Catatan: Profil Batin memberi fokus tazkiyah & adab; faktor bulan boleh ditambah sebagai modul berasingan jika diperlukan.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ProfilBatinCard;
