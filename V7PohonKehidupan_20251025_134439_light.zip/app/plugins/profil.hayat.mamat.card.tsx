// === OVERWRITE PENUH: app/plugins/profil.hayat.mamat.card.tsx ===
import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ============ UI mini helpers (tema gelap) ============ */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

/* ============ Kaedah klasik al-Būnī =============
   jumlah = (Nama + Nama Ibu + Hari + Baki Bulan Hijri)
   → ganjil = AL-HAYAT
   → genap  = AL-MAMAT
   Nota: ي و ء ة = 0, "لا" = 31
================================================== */

function normalizeArabic(input:string){
  const s = (input||"")
    .replace(/[^\u0600-\u06FF]/g,"")
    .replace(/[ًٌٍَُِْٰـۭۣۢۚۗۙۛۜ۟۠ۡۢۤۧۨ]/g,"");
  return [...s].map(ch=>{
    if (ch==="ة") return "";
    if (ch==="أ"||ch==="إ"||ch==="آ"||ch==="ٱ") return "ا";
    if (ch==="ى"||ch==="ئ") return "ي";
    if (ch==="ؤ") return "و";
    return ch;
  }).join("");
}

const ABJAD: Record<string, number> = {
  "ا":1,"ب":2,"ج":3,"د":4,
  "ه":0,"و":0,"ز":7,"ح":8,"ط":9,"ي":0,
  "ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
  "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,
  "ء":0,"لا":31,"ة":0
};

type LetterBreak={ch:string;val:number};
function abjadSum(raw:string){
  if(!raw) return {total:0,letters:[] as LetterBreak[]};
  let s=raw.trim();let total=0;const letters:LetterBreak[]=[];
  s=s.replace(/لا/g,()=>{total+=31;letters.push({ch:"لا",val:31});return""});
  for(const ch of s){const v=ABJAD[ch]??0;total+=v;if(v)letters.push({ch,v});}
  return{total,letters};
}

/* Hari, Planet & Malaikat */
const HARI_INFO=[
  {h:"Ahad",idx:1,planet:"Matahari (Shams)",malaikat:"Mikā’īl"},
  {h:"Isnin",idx:2,planet:"Bulan (Qamar)",malaikat:"Jibrīl"},
  {h:"Selasa",idx:3,planet:"Marīkh (Mars)",malaikat:"Samā’īl"},
  {h:"Rabu",idx:4,planet:"ʿUṭārid (Mercury)",malaikat:"Rāfa’īl"},
  {h:"Khamis",idx:5,planet:"Mushtarī (Jupiter)",malaikat:"Ṣarfā’īl"},
  {h:"Jumaat",idx:6,planet:"Zuhrah (Venus)",malaikat:"Anā’īl"},
  {h:"Sabtu",idx:7,planet:"Zuhal (Saturn)",malaikat:"Kaṭhā’īl"},
] as const;
type HariName=(typeof HARI_INFO)[number]["h"];
const HARI_LIST:HariName[]=HARI_INFO.map(x=>x.h);
const HARI_ABJAD:Record<HariName,number>=Object.fromEntries(HARI_INFO.map(x=>[x.h,x.idx])) as Record<HariName,number>;

function kiraLauh(nama:string,ibu:string,hari:HariName|"",hijriDay:number|undefined){
  if(!nama||!ibu||!hari||!hijriDay||hijriDay<1||hijriDay>30)return null;
  const tn=abjadSum(normalizeArabic(nama)).total;
  const ti=abjadSum(normalizeArabic(ibu)).total;
  const hv=HARI_ABJAD[hari];
  const baki=30-hijriDay;
  const jumlah=tn+ti+hv+baki;
  const lauh=(jumlah%2===1)?"AL-HAYAT":"AL-MAMAT";
  return{jumlah,lauh};
}

/* ============ KAD ============ */
const CardHayatMamatClassic:ExplainAdapter={
  id:"profil-hayat-mamat-classic",
  label:"Lauh al-Hayāt / al-Mamāt — Kaedah Klasik (al-Būnī)",
  render(){
    const[nama,setNama]=useState("");const[ibu,setIbu]=useState("");
    const[hari,setHari]=useState<HariName|"">("");const[hijriDay,setHijriDay]=useState("");
    const pecahanNama=useMemo(()=>abjadSum(normalizeArabic(nama)),[nama]);
    const pecahanIbu=useMemo(()=>abjadSum(normalizeArabic(ibu)),[ibu]);
    const hijriNum=useMemo(()=>Number(hijriDay)||NaN,[hijriDay]);
    const baki=useMemo(()=>!Number.isFinite(hijriNum)||hijriNum<1||hijriNum>30?null:30-hijriNum,[hijriNum]);
    const hasil=useMemo(()=>kiraLauh(nama,ibu,hari,hijriNum),[nama,ibu,hari,hijriNum]);
    const hariInfo=useMemo(()=>HARI_INFO.find(x=>x.h===hari),[hari]);
    const clearAll=()=>{setNama("");setIbu("");setHari("");setHijriDay("");};

    return(
      <Accordion title="Lauh al-Hayāt / al-Mamāt — Kaedah Klasik (al-Būnī)">
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input</Text>
          <Text style={{color:"#e8e6e3"}}>Nama (Arab/Jawi)</Text>
          <TextInput value={nama}onChangeText={setNama}placeholder="cth: محمد"placeholderTextColor="#777"style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}}/>
          <Text style={{color:"#e8e6e3"}}>Nama Ibu (Arab/Jawi)</Text>
          <TextInput value={ibu}onChangeText={setIbu}placeholder="cth: فاطمة"placeholderTextColor="#777"style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:10}}/>
          <Text style={{color:"#e8e6e3",marginBottom:6}}>Hari</Text>
          <View style={{flexDirection:"row",flexWrap:"wrap"}}>{HARI_LIST.map(h=>(<Chip key={h}label={h}active={hari===h}onPress={()=>setHari(h)}/>))}</View>
          <Text style={{color:"#e8e6e3",marginTop:8}}>Hari Hijri (1–30)</Text>
          <TextInput value={hijriDay}onChangeText={setHijriDay}placeholder="cth: 12"keyboardType="number-pad"placeholderTextColor="#777"style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8}}/>
          <TouchableOpacity onPress={clearAll}style={{marginTop:8}}><Text style={{color:"#9a9692",textDecorationLine:"underline"}}>Kosongkan</Text></TouchableOpacity>
          <Text style={{color:"#9a9692",marginTop:10,fontSize:12,lineHeight:18}}>
            Berdasarkan <Text style={{fontStyle:"italic"}}>Shams al-Maʿārif al-Kubrā</Text>: hitung (Nama + Nama Ibu + Hari + Baki bulan Hijri),
            kemudian “اعرضه على اللوحين” — jika jatuh pada <Text style={{fontWeight:"700"}}>Lauh al-Hayāt</Text> → kehidupan/barakah;
            pada <Text style={{fontWeight:"700"}}>Lauh al-Mamāt</Text> → ujian/pembersihan.
          </Text>
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Ringkasan</Text>
          <Row l="Jumlah Nama"r={pecahanNama.total||"—"}/>
          <Row l="Jumlah Ibu"r={pecahanIbu.total||"—"}/>
          <Row l="Nilai Hari"r={hari?HARI_ABJAD[hari]:"—"}/>
          <Row l="Baki Hijri"r={baki??"—"}c="#ff4d57"/>
          <Row l="Jumlah Keseluruhan"r={hasil?.jumlah??"—"}c="#ff4d57"/>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Planet & Malaikat Penjaga</Text>
          {hariInfo?
            (<>
              <Row l="Hari"r={hariInfo.h}/>
              <Row l="Planet"r={hariInfo.planet}/>
              <Row l="Malaikat ḥākim"r={hariInfo.malaikat}/>
              <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>Isyarat penjaga hari untuk adab & muhasabah.</Text>
            </>):
            (<Text style={{color:"#c9c6c2"}}>Pilih hari untuk lihat planet & malaikat ḥākim.</Text>)
          }
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Keputusan Lauh</Text>
          {hasil?
            (<>
              <Row l="Lauh"r={hasil.lauh==="AL-HAYAT"?"AL-HAYĀT (Hidup/Barakah)":"AL-MAMĀT (Ujian/Pembersihan)"}c={hasil.lauh==="AL-HAYAT"?"#7bd1c9":"#ffb3b8"}/>
              <Text style={{color:"#c9c6c2",marginTop:6}}>Adab Nabawi: jika jatuh Mamāt → ubah/tambah nama & perbanyak zikir pengimbang (يَا سَلَامُ • يَا لَطِيفُ).</Text>
            </>):
            (<Text style={{color:"#c9c6c2"}}>Lengkapkan input untuk keputusan.</Text>)
          }
        </Box>
      </Accordion>
    );
  }
};
export default CardHayatMamatClassic;
