import React, { useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ===== Util UI (tema merah-gaming) ===== */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

/* ===== Normalisasi & Abjad — ي ه و ء ة = 0 ===== */
type TaMode = "ha" | "ta";
function normalizeArabic(input:string, taMode:TaMode){
  const s = (input||"")
    .replace(/[^\u0600-\u06FF]/g,"")
    .replace(/[ًٌٍَُِْٰـۭۣۢۚۗۙۛۜ۟۠ۡۢۤۧۨ]/g,""); // buang baris
  return [...s].map(ch=>{
    if (["ي","ه","و","ء","ة"].includes(ch)) return ""; // 0 kosong
    if (ch==="أ"||ch==="إ"||ch==="آ") return "ا";
    if (ch==="ى") return "ي";
    return ch;
  }).join("");
}
const ABJAD: Record<string, number> = {
  "ا":1,"ب":2,"ج":3,"د":4,"ه":0,"و":0,"ز":7,"ح":8,"ط":9,"ي":0,
  "ك":20,"ل":30,"م":40,"ن":50,"س":60,"ع":70,"ف":80,"ص":90,
  "ق":100,"ر":200,"ش":300,"ت":400,"ث":500,"خ":600,"ذ":700,"ض":800,"ظ":900,"غ":1000,
  "ء":0,"ة":0,"لا":31
};
function abjadSum(raw: string){
  if (!raw) return { total: 0, letters: [] as { ch: string; val: number }[] };
  let s = raw.trim();
  let total = 0;
  const letters: { ch: string; val: number }[] = [];
  s = s.replace(/لا/g, () => { total += 31; letters.push({ ch: "لا", val: 31 }); return ""; });
  for (const ch of s) {
    const val = ABJAD[ch] ?? 0;
    total += val;
    if (val) letters.push({ ch, val });
  }
  return { total, letters };
}
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

/* ===== Pemetaan Unsur/Planet/Burj (Shams, kekal) ===== */
const UNSUR = [
  {k:1,n:"Api",   m:"Asal tenaga & keberanian. Kawal panas hati, suburkan tawaduk."},
  {k:2,n:"Angin", m:"Komunikasi, idea. Jaga fokus & tertib."},
  {k:3,n:"Air",   m:"Kasih & serapan emosi. Letak sempadan sihat."},
  {k:4,n:"Tanah", m:"Asas & amanah. Elak kaku, tambah empati."},
] as const;
const PLANET = [
  {k:1,n:"Zuhal",    m:"Ujian/pembersihan nasab; sabar & tutup aib keluarga."},
  {k:2,n:"Musytari", m:"Futuh rezeki & ilmu; syukur & urus harta waris."},
  {k:3,n:"Marikh",   m:"Sengketa; damai & adab dalam rumah/adik-beradik."},
  {k:4,n:"Matahari", m:"Kemuliaan nama keluarga; elak riya’ keturunan."},
  {k:5,n:"Zuhrah",   m:"Ikatan kasih ibu; haluskan budi & layanan."},
  {k:6,n:"Utarid",   m:"Amanah kalam & dokumen; teliti wasiat/surat."},
  {k:7,n:"Bulan",    m:"Rumahtangga & memori; pelihara sakinah."},
] as const;
const BURJ = [
  {k:1,n:"Hamal",u:"Api",m:"Pintu mula nasab; perkemas adab awal (nama, aqiqah)."},
  {k:2,n:"Thawr",u:"Tanah",m:"Harta keluarga & asas; urus milik & nafkah."},
  {k:3,n:"Jawza",u:"Angin",m:"Silaturahim luas; kuat komunikasi tabiin/sanak."},
  {k:4,n:"Sartan",u:"Air",m:"Rumah & ibu pusat sakinah; hormat ibu."},
  {k:5,n:"Asad",u:"Api",m:"Karisma keluarga; guna kuasa untuk khidmat."},
  {k:6,n:"Sumbulah",u:"Tanah",m:"Tertib, khidmat; jaga adab harian."},
  {k:7,n:"Mizan",u:"Angin",m:"Keadilan hak keluarga; elak zalim halus."},
  {k:8,n:"Aqrab",u:"Air",m:"Rahsia, penyembuhan; jangan buka aib keluarga."},
  {k:9,n:"Qaws",u:"Api",m:"Safar & menuntut ilmu keluarga."},
  {k:10,n:"Jadi",u:"Tanah",m:"Taklif/waris; tunaikan tanggungjawab."},
  {k:11,n:"Dalw",u:"Angin",m:"Jamaah/komuniti; jaga maruah keluarga."},
  {k:12,n:"Hut",u:"Air",m:"Penutupan baik; doakan arwah & salasilah."},
] as const;
const fasa30 = (b:number)=>{
  const v=(Math.trunc(b)||30);
  if(v<=10) return {t:"Pembukaan Nasab", s:"Kuatkan adab kepada ibu, jaga lafaz nama & doa ibu."};
  if(v<=20) return {t:"Ujian Nasab", s:"Redakan konflik keluarga; urus hutang/waris & maafkan."};
  return {t:"Penutupan Kitaran", s:"Muhasabah salasilah; sedekah untuk ibu/nenek, tutup aib."};
};
const colorUnsur=(u?:string)=>u==="Api"?"#ff4d57":u==="Tanah"?"#b48b5a":u==="Angin"?"#77c0ff":u==="Air"?"#7bd1c9":"#e8e6e3";

/* ===== Kad: Tafsir Asal Nasab / Spiritual (Nama Diri + Ibu) ===== */
const CardNasabUmmahat: ExplainAdapter = {
  id: "profil-nasab-ummahat",
  label: "Tafsir Asal Nasab / Spiritual — (Nama Diri + Ibu)",
  render() {
    const [nama,setNama] = useState("");
    const [ibu,setIbu]   = useState("");
    const [ta,setTa]     = useState<TaMode>("ha");

    const sNama = useMemo(()=>normalizeArabic(nama, ta),[nama,ta]);
    const sIbu  = useMemo(()=>normalizeArabic(ibu,  ta),[ibu,ta]);
    const aNama = useMemo(()=>abjadSum(sNama),[sNama]);
    const aIbu  = useMemo(()=>abjadSum(sIbu), [sIbu]);

    const totalNasab = aNama.total + aIbu.total;
    const baki       = (totalNasab % 30) || 30;
    const m4  = modWrap(totalNasab,4);
    const m7  = modWrap(totalNasab,7);
    const m12 = modWrap(totalNasab,12);

    const U = UNSUR.find(x=>x.k===m4)!;
    const P = PLANET.find(x=>x.k===m7)!;
    const B = BURJ.find(x=>x.k===m12)!;
    const F = fasa30(baki);

    const flags:string[] = [];
    if (m4===1 && m7===3 && (m12===1||m12===5)) flags.push("Isyarat panas nasab — elak ungkit aib lama; dahulukan damai & maaf.");
    if (m4===3 && m7===5 && (m12===4||m12===12)) flags.push("Rahmah ibu dominan — muliakan ibu, hidupkan suasana sakinah di rumah.");
    if (m4===4 && m7===1 && (m12===2||m12===10)) flags.push("Taklif waris — semak wasiat/dokumen; urus hutang & nafkah.");
    if (!flags.length) flags.push("Nasab seimbang — kekalkan adab, doa ibu & sambung silaturahim.");

    const clear=()=>{ setNama(""); setIbu(""); };

    return (
      <Accordion title="Tafsir Asal Nasab / Spiritual — (Nama Diri + Ibu)">
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input (Jawi/Arab)</Text>
          <Text style={{color:"#e8e6e3"}}>Nama Diri</Text>
          <TextInput value={nama} onChangeText={setNama} placeholder="cth: علي" placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}} />
          <Text style={{color:"#e8e6e3"}}>Nama Ibu</Text>
          <TextInput value={ibu} onChangeText={setIbu} placeholder="cth: فاطمة" placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8}} />
          <Text style={{color:"#e8e6e3",marginTop:8, marginBottom:6}}>Ta marbūṭah (ة)</Text>
          <View style={{flexDirection:"row"}}>
            <Chip label="dikira ه (0)"  active={ta==="ha"} onPress={()=>setTa("ha")} color="#888" />
            <Chip label="dikira ت (0)"  active={ta==="ta"} onPress={()=>setTa("ta")} color="#888" />
          </View>
          <TouchableOpacity onPress={clear} style={{marginTop:8}}>
            <Text style={{color:"#9a9692",textDecorationLine:"underline"}}>Kosongkan</Text>
          </TouchableOpacity>
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Huruf ي ه و ء ة kini dikira 0 (kosong) tanpa menjejaskan kiraan lain.
          </Text>
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Ringkasan Kiraan Nasab</Text>
          <Row l="Jumlah Nama Diri" r={aNama.total}/>
          <Row l="Jumlah Nama Ibu" r={aIbu.total}/>
          <Row l="Jumlah Nasab (Diri+Ibu)" r={totalNasab} c="#ff4d57"/>
          <Row l="Baki 30" r={baki} c="#ff4d57"/>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Tafsiran Nasab</Text>
          <Row l="Unsur Nasab" r={U.n} c={colorUnsur(U.n)} />
          <Row l="Planet Naungan" r={P.n}/>
          <Row l="Burj Nasab" r={`${B.n} (${B.u})`} />
          <Row l="Fasa (Baki 30)" r={F.t} />
          <Text style={{color:"#c9c6c2", marginTop:6}}>{U.m}</Text>
          <Text style={{color:"#c9c6c2"}}>{P.m}</Text>
          <Text style={{color:"#c9c6c2"}}>{B.m}</Text>
          <Text style={{color:"#c9c6c2"}}>• Saran fasa: {F.s}</Text>
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Isyarat Khas Nasab</Text>
          {flags.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2",marginBottom:4}}>{`\u2022 ${t}`}</Text>))}
          <Text style={{color:"#9a9692",marginTop:6,fontSize:12}}>
            Baca sebagai muhasabah & adab (wiqāyah); elakkan ritual/azimat.
          </Text>
        </Box>

        <Text style={{color:"#9a9692",fontSize:12}}>
          Sumber: Shams al-Maʿārif (al-Būnī), bab “al-Asrār fī Asmāʾ al-Ummahāt”.
        </Text>
      </Accordion>
    );
  }
};

export default CardNasabUmmahat;
