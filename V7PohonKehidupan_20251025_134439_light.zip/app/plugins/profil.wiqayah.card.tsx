import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/**
 * Indeks Hijab & Wiqāyah
 * --------------------------------------------------
 * Berdasar pada gabungan m4 (unsur), m7 (planet), m12 (burj) dan baki30.
 * Hasil: risiko ghaib 0–3 + nasihat perlindungan/adab zahir-batin.
 */

// helpers
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

// definisi asas
const UNSUR = ["Api","Angin","Air","Tanah"];
const PLANET = ["Zuhal","Musytari","Marikh","Matahari","Zuhrah","Utarid","Bulan"];
const BURJ = ["Hamal","Thawr","Jawza","Sartan","Asad","Sumbulah","Mizan","Aqrab","Qaws","Jadi","Dalw","Hut"];

// peta risiko — 0=neutral,1=rendah,2=sedang,3=tinggi
function kiraRisiko(u:number,p:number,b:number,b30:number){
  // pola tertentu dari kitab Shams (dimurnikan)
  if (u===1 && p===3) return 3; // Api × Marikh = panas kuat
  if (u===3 && p===5) return 2; // Air × Zuhrah = lembut tapi mudah terdedah
  if (u===2 && p===7) return 2; // Angin × Bulan = lintasan
  if (u===4 && p===1) return 2; // Tanah × Zuhal = berat beban
  if (b===8 || b===12) return 2; // Aqrab/Hut = sirr & kesan batin
  if (b30>=11 && b30<=20) return 1; // fasa tengah = ujian
  return 0;
}

// tafsiran teks
const NASIHAT = {
  0: {
    label:"Neutral / Selamat",
    nasihat:[
      "Keseimbangan zahir & batin terpelihara.",
      "Teruskan adab asas: istighfar, selawat, jaga janji.",
      "Rumah & tidur berwudhu’ kekalkan ketenangan."
    ]
  },
  1: {
    label:"Ujian Ringan",
    nasihat:[
      "Lazimkan zikir pagi-petang & istighfar.",
      "Kurangkan interaksi negatif / pamer diri.",
      "Teguhkan adab makan, tidur, dan janji."
    ]
  },
  2: {
    label:"Lintasan / Serapan Emosi",
    nasihat:[
      "Amalkan perlindungan: Ayat Kursi, 3 Qul, doa Nabi Yunus.",
      "Elak debat & tempat sesak.",
      "Jaga kebersihan hati & rumah."
    ]
  },
  3: {
    label:"Tekanan Ghaib / Panas Tinggi",
    nasihat:[
      "Sejukkan dengan wudhu’ & solat sunat ringan.",
      "Kurangkan pendedahan awam/pentas/pengaruh luar.",
      "Amal istighfar 100× dan tidur dalam zikir."
    ]
  }
};

// UI helper
const Box: React.FC<{children:any,alt?:boolean}> = ({children,alt}) => (
  <View style={{
    backgroundColor: alt? "#100a0b" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#351920" : "#2a0e14"
  }}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#e8e6e3", opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

const ProfilWiqayahCard: ExplainAdapter = {
  id: "wiqayah",
  label: "Indeks Hijab & Wiqāyah (Perlindungan)",
  render({ aDiri=0, aIbu=0, aIsteri=0, aAnakJumlah=0 }: Input) {
    const total = aDiri + aIbu + aIsteri + aAnakJumlah;
    const m4  = modWrap(total,4);
    const m7  = modWrap(total,7);
    const m12 = modWrap(total,12);
    const b30 = (total%30)||30;

    const risiko = kiraRisiko(m4,m7,m12,b30);
    const data = NASIHAT[risiko as 0|1|2|3];

    return (
      <Accordion title="Indeks Hijab & Wiqāyah (Perlindungan)">
        <Box>
          <Row l="Jumlah Tawāfiq" r={total} />
          <Row l="Unsur" r={UNSUR[m4-1]} />
          <Row l="Planet" r={PLANET[m7-1]} />
          <Row l="Burj" r={BURJ[m12-1]} />
          <Row l="Baki 30" r={b30} />
        </Box>

        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>
            Tahap Risiko: <Text style={{color:"#ff4d57"}}>{data.label}</Text>
          </Text>
          {data.nasihat.map((t,i)=>(
            <Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>
          ))}
        </Box>

        <Text style={{color:"#9a9692", marginTop:8, fontSize:12}}>
          Nota: Penilaian simbolik berasaskan pola Shams klasik (unsur × planet × burj). 
          Tujuannya sebagai panduan adab & penjagaan diri, bukan ramalan ghaib.
        </Text>
      </Accordion>
    );
  }
};
export default ProfilWiqayahCard;
