import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/**
 * Asrār al-Arqām — Rahsia Angka (Lengkap)
 * ---------------------------------------
 * Auto-hook jumlah tawāfiq → mod12 (buruj), baki30 (fasa), angka54 (1..54).
 * Fokus: pendidikan & adab (bukan ritual/ramalan).
 */

const C = { bg:"#14090b", sub:"#0f0a0b", line:"#2a0e14", text:"#e8e6e3", accent:"#ff4d57", dim:"#9a9692", ok:"#7dff8a", warn:"#ffd86b", stop:"#ff7d7d" };

const Box: React.FC<{children:any, alt?:boolean}> = ({children, alt}) => (
  <View style={{backgroundColor:alt?C.sub:C.bg, borderRadius:12, padding:12, marginBottom:10, borderWidth:1, borderColor:C.line}}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c=C.text}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:C.text, opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

/** Buruj mod12 (padat, jelas) */
const BURUJ = [
  {k:1,n:"Hamal",m:"Pelopor berani; sesuai mula projek; kawal tergesa."},
  {k:2,n:"Thawr",m:"Memperkukuh asas/harta; sabar; elak keras kepala."},
  {k:3,n:"Jawza",m:"Komunikasi & ilmu; pantas; jauhi celaru & gosip."},
  {k:4,n:"Sartan",m:"Rumah & keluarga; peka emosi; tetapkan batas."},
  {k:5,n:"Asad",m:"Kepimpinan & nama; jaga tawaduk; adil pada orang."},
  {k:6,n:"Sumbulah",m:"Tertib & khidmat; teliti; jangan over-critical."},
  {k:7,n:"Mizan",m:"Keadilan, rundingan; harmoni; tegas bila perlu."},
  {k:8,n:"Aqrab",m:"Rahsia & transformasi; jaga sirr & niat."},
  {k:9,n:"Qaws",m:"Safar & visi; luas pandang; elak melulu."},
  {k:10,n:"Jadi",m:"Struktur, taklif; kerja keras; elak kaku."},
  {k:11,n:"Dalw",m:"Inovasi, komuniti; reformasi; adab berbeza pendapat."},
  {k:12,n:"Hut",m:"Ilham, penutupan; kasih; muhasabah & tenang."},
] as const;

/** Fasa baki30 */
function fasaBaki30(b:number){
  const v = (Math.trunc(b)||30);
  if (v<=10) return {label:"Pembukaan", warna:C.ok, nasihat:"Tenaga naik; mula projek; niat & pelan jelas."};
  if (v<=20) return {label:"Ujian", warna:C.warn, nasihat:"Tahan emosi; kurangkan pendedahan; kekal tertib."};
  return {label:"Penutupan", warna:C.stop, nasihat:"Sapu hutang/isu tertunggak; muhasabah; susun semula."};
}

/** Tafsiran angka 1..54 (maksud + fokus amali) — ringkas padat */
type ARec = { m:string; f:string };
const A: Record<number, ARec> = {
  1:{m:"Asal/niat pertama; keberanian memulakan.",f:"Tetapkan niat & objektif ringkas."},
  2:{m:"Dwi-kuasa/pasangan; keseimbangan lawan.",f:"Cari rakan kongsi/seimbangkan kerja-rumah."},
  3:{m:"Trilogi akal-hati-nafs; kreatif.",f:"Strukturkan idea; pilih 3 langkah terdekat."},
  4:{m:"Empat unsur/arah; asas kukuh.",f:"Bina rutin & SOP; elak lompat-lompat."},
  5:{m:"Pancaindera; gerak zahir.",f:"Jaga deria & kesihatan; disiplin jadual."},
  6:{m:"Tertib/taqdir; usaha berterusan.",f:"Konsisten 6 hari; rehat berjadual."},
  7:{m:"Langit/planet; dimensi makna.",f:"Tambah ilmu; hormati autoriti & adab."},
  8:{m:"Penopang; kekuatan ghaib/adab.",f:"Pegang amanah; elak pamer kekuatan."},
  9:{m:"Penutup kitaran; hikmah.",f:"Tutup projek; dokumentasi; syukur."},
  10:{m:"Pembukaan baharu; skala lebih besar.",f:"Naik taraf alat & proses kerja."},
  11:{m:"Ilham & komuniti.",f:"Rapatkan jaringan; elak ‘echo chamber’."},
  12:{m:"Kitaran buruj; peta setahun.",f:"Rancang tahunan; sasaran 12 bulan."},
  13:{m:"Amaran/semak; potensi salah faham.",f:"Semak kontrak/komunikasi dulu."},
  14:{m:"Pengukuhan ikatan/struktur.",f:"Kemaskan perjanjian & peranan."},
  15:{m:"Pembersihan/kemaafan.",f:"Selesaikan hutang; maafkan; tenangkan hati."},
  16:{m:"Pemotongan/ketegasan.",f:"Putus beban toksik; fokus prioriti."},
  17:{m:"Maruah/nama baik.",f:"Jaga reputasi; elak riya’; konsisten."},
  18:{m:"Keberanian berhikmah.",f:"Tegas berprinsip; rujuk orang alim."},
  19:{m:"Gerak pantas/pemulihan.",f:"Selesaikan kerja tertangguh."},
  20:{m:"Rehat & susun semula.",f:"Rehat aktif; audit jadual & kewangan."},
  21:{m:"Asas baharu/‘tanah’ segar.",f:"Mulakan infrastruktur kecil."},
  22:{m:"Korban untuk lega.",f:"Lepaskan komitmen tak perlu."},
  23:{m:"Penerimaan hakikat.",f:"Terima plan B; teruskan bergerak."},
  24:{m:"Nasib baik naik (saʿd).",f:"Ambil peluang; jangan leka."},
  25:{m:"Sembunyi/sedia.",f:"Simpan tenaga; siapkan plan kecemasan."},
  26:{m:"Pengosongan awal.",f:"Habiskan fail lama; tutup loop."},
  27:{m:"Pengosongan kedua.",f:"Sapu bersih komitmen; arkibkan."},
  28:{m:"Takhtim kitaran qamar.",f:"Muhasabah; siapkan niat baharu."},
  29:{m:"Ambang bulan baharu.",f:"Preview agenda; minimakan risiko."},
  30:{m:"Penutupan sempurna.",f:"Serah & syukur; reset sistem."},
  31:{m:"Lintasan halus meningkat.",f:"Perkuat zikir asas; jaga tidur."},
  32:{m:"Jambatan zahir-batin.",f:"Seimbangkan kerja–keluarga–ibadah."},
  33:{m:"Kemuliaan akhlak.",f:"Latih ihsan; elak pamer kebaikan."},
  34:{m:"Isyarat ilmu tersirat.",f:"Catat ilham; semak dengan guru."},
  35:{m:"Empati mendalam.",f:"Tetapkan sempadan; jangan tenggelam."},
  36:{m:"Tertib rohani.",f:"Kecilkan beban; disiplin wirid asas."},
  37:{m:"Keputusan ilham.",f:"Padankan data + intuisi; putuskan."},
  38:{m:"Hijab ego nipis.",f:"Rendahkan diri; elak debat sia-sia."},
  39:{m:"Nama baik diuji.",f:"Pilih diam bermakna; jaga janji."},
  40:{m:"Ambang hikmah.",f:"Tuntut ilmu mendalam; berguru."},
  41:{m:"Pembersihan batin.",f:"Istighfar + kemas ruang hidup."},
  42:{m:"Keadilan halus.",f:"Betulkan hak orang; telus rekod."},
  43:{m:"Ujian kesetiaan.",f:"Kekal pada kebenaran walau sunyi."},
  44:{m:"Kekuatan tersembunyi.",f:"Kerja senyap; hasilkan impak."},
  45:{m:"Penutupan ghaibiyyah.",f:"Kurang pendedahan; fokus isi."},
  46:{m:"Nur makna.",f:"Cari makna; ringkaskan hidup."},
  47:{m:"Khidmat murni.",f:"Bantu tanpa publisiti; amanah."},
  48:{m:"Tawakkal & tenang.",f:"Serah hasil; redha cerdas."},
  49:{m:"Maqam sabar.",f:"Tahan ujian; jangan mengeluh."},
  50:{m:"Warak & integriti.",f:"Tolak yang syubhah; jelas nilai."},
  51:{m:"Syukur mendalam.",f:"Rakaman syukur harian; sedekah."},
  52:{m:"Firasat bersih.",f:"Keputusan bening; jauhi bisik buruk."},
  53:{m:"Ikhlas & rahsia amal.",f:"Rahsiakan kebajikan; jauh riya’."},
  54:{m:"Kamil – penutup hikmah.",f:"Tutup kitaran; serah diri kepada Allah."},
};

/** Ringkaskan lapis 1..54 */
function lapis(n:number){
  if (n<=9) return "Asal (1–9)";
  if (n<=27) return "Amal (10–27)";
  if (n<=45) return "Ghaibiyyah (28–45)";
  return "Kamil (46–54)";
}

const ArqamCard: import("../adapters/types").ExplainAdapter = {
  id: "arqam",
  label: "Asrār al-Arqām — Rahsia Angka (Lengkap)",
  render({ aDiri=0, aIbu=0, aIsteri=0, aAnakJumlah=0 }: Input) {
    const total = (aDiri||0)+(aIbu||0)+(aIsteri||0)+(aAnakJumlah||0);
    const m12 = modWrap(total,12);
    const b30 = (total%30)||30;
    const a54 = (total%54)||54;

    const B = BURUJ[m12-1];
    const F = fasaBaki30(b30);
    const L = A[a54];

    return (
      <Accordion title="Asrār al-Arqām — Rahsia Angka (Lengkap)">
        {/* Ringkasan angka */}
        <Box>
          <Row l="Jumlah Tawāfiq" r={total} />
          <Row l="Buruj (mod12)" r={`${B.k} — ${B.n}`} c="#7fe3ff" />
          <Row l="Fasa (baki30)" r={`${b30} — ${F.label}`} c={F.warna} />
          <Row l="Angka (1–54)" r={`${a54} — ${lapis(a54)}`} c="#ffb07d" />
          <Text style={{color:C.dim, marginTop:6, fontSize:12}}>
            Nilai diambil automatik dari kalkulator (jumlah huruf Jawi).
          </Text>
        </Box>

        {/* Tafsir Baki 30 */}
        <Box alt>
          <Text style={{color:C.text, fontWeight:"800", marginBottom:6}}>Fasa — Baki 30</Text>
          <Text style={{color:C.text}}>• {F.label}: <Text style={{color:F.warna, fontWeight:"700"}}>{F.nasihat}</Text></Text>
        </Box>

        {/* Tafsir Buruj */}
        <Box>
          <Text style={{color:C.text, fontWeight:"800", marginBottom:6}}>Buruj — mod12</Text>
          <Text style={{color:"#c9c6c2"}}>{B.m}</Text>
        </Box>

        {/* Tafsir Angka 1–54 */}
        <Box alt>
          <Text style={{color:C.text, fontWeight:"800", marginBottom:6}}>Angka {a54} — {lapis(a54)}</Text>
          <Text style={{color:"#c9c6c2"}}>• Maksud: {L.m}</Text>
          <Text style={{color:"#c9c6c2"}}>• Fokus amali: {L.f}</Text>
        </Box>

        {/* Panduan amali ringkas */}
        <Box>
          <Text style={{color:C.text, fontWeight:"800", marginBottom:6}}>Panduan Ringkas</Text>
          <Text style={{color:"#c9c6c2"}}>• Selaraskan jadual dengan fasa (baki30).</Text>
          <Text style={{color:"#c9c6c2"}}>• Guna kekuatan buruj untuk strategi & komunikasi.</Text>
          <Text style={{color:"#c9c6c2"}}>• Angka 1–54: ikut fokus amali harian.</Text>
          <Text style={{color:C.dim, marginTop:6, fontSize:12}}>
            Tafsiran simbolik dari tradisi Shams/al-Būnī — untuk muhasabah & adab.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ArqamCard;
