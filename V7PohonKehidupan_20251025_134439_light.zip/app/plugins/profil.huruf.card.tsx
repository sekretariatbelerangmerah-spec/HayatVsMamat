import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/* ─── UTIL NORMALISASI JAWI ─── */
const clean = (s?: string) =>
  (s||"")
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g,"") // buang harakat
    .replace(/\u0640/g,"")                              // tatweel
    .replace(/[^\u0621-\u06FF\s]/g,"")                  // hanya huruf Arab
    .trim();

const unify = (s:string) => s
  .replace(/[\u0622\u0623\u0625]/g,"\u0627") // alif variasi
  .replace(/\u0649/g,"\u064A")               // alif maqsura → ya
  .replace(/\u0629/g,"\u0647");              // ta marbuta → ha

const letters = (s:string)=>clean(unify(s)).split("").filter(Boolean);

/* ─── PETA TAFSIRAN HURUF (AL-BŪNĪ) ─── */
type Rule={h:string,judul:string,maksud:string};

const RULES_AWAL:Rule[]=[
{h:"ا",judul:"Pelopor Tauhid",maksud:"Watak pelancar & berjiwa pemimpin; jaga niat & elak takabbur."},
{h:"ب",judul:"Lembut & Rahmah",maksud:"Penyayang, menarik rezeki; jangan mudah diperalat."},
{h:"ج",judul:"Ilmu & Analitik",maksud:"Suka ilmu dan hikmah; kawal keangkuhan."},
{h:"د",judul:"Tegas & Putus",maksud:"Cenderung cepat bertindak; jaga kesabaran."},
{h:"ه",judul:"Halus Hati",maksud:"Peka & rahsia; perlukan kestabilan emosi."},
{h:"و",judul:"Ikatan & Amanah",maksud:"Suka janji & hubungan; wajib jujur & tepat kata."},
{h:"ز",judul:"Seni & Keindahan",maksud:"Cinta estetika; awasi hawa & riya’."},
{h:"ح",judul:"Kesucian",maksud:"Khidmat, perawatan; jagalah kesihatan & niat suci."},
{h:"ط",judul:"Ketahanan",maksud:"Berani, kuat; elak kasar."},
{h:"ي",judul:"Akal & Kalam",maksud:"Bijak berkata & menulis; elak teori tanpa amal."},
{h:"ك",judul:"Kekuasaan",maksud:"Cenderung memimpin; elak zalim."},
{h:"ل",judul:"Pendamai",maksud:"Suka harmoni; tegas bila perlu."},
{h:"م",judul:"Tertib",maksud:"Sistematik; awasi keras diri."},
{h:"ن",judul:"Empati",maksud:"Mendidik & memahami; kawal simpati berlebihan."},
{h:"س",judul:"Dakwah & Bicara",maksud:"Penyampai; kuatkan hujah & adab."},
{h:"ع",judul:"Rasa & Ma‘rifah",maksud:"Cinta hakikat; perlu guru mursyid."},
{h:"ف",judul:"Idea & Futuh",maksud:"Kreatif; susun tindakan."},
{h:"ص",judul:"Sabar & Tekanan",maksud:"Menanggung ujian; elak murung."},
{h:"ق",judul:"Kekuatan Qalb",maksud:"Teguh jiwa; elak keras kepala."},
{h:"ر",judul:"Kharisma",maksud:"Menarik; jaga niat & elak riya’."},
{h:"ت",judul:"Cepat & Cekap",maksud:"Tindakan pantas; hindari gopoh."},
{h:"ث",judul:"Eksperimen",maksud:"Ingin tahu; awasi hujah kosong."},
{h:"خ",judul:"Hijab & Penjagaan",maksud:"Privasi; jujur pada kebenaran."},
{h:"ذ",judul:"Hak & Keadilan",maksud:"Berani tegak hak; kawal lidah."},
{h:"ض",judul:"Ujian Berat",maksud:"Tabah & sabar; hasilnya tinggi."},
{h:"ظ",judul:"Zahir Kuat",maksud:"Nampak luaran; lembutkan batin."},
{h:"غ",judul:"Misteri & Ghayb",maksud:"Minat ghaib; berpada dengan ilmu sahih."},
];

const RULES_ULANG:Record<string,string>={
"م":"Tertib & Amanah",
"ن":"Empati & Didik",
"ل":"Pendamai",
"س":"Komunikasi & Dakwah",
"ر":"Kharisma"
};

const RULES_JARANG:Record<string,string>={
"خ":"Perlu jaga privasi & adab ghaib",
"غ":"Perlu panduan ilmu ghaib",
"ث":"Latih komunikasi berdalil",
"ذ":"Latih keadilan & tutur",
"ظ":"Perhalus bahasa & hujah",
"ص":"Perkuat sabar",
"ض":"Perlu lapang dada"
};

/* ─── UI KECIL ─── */
const Box:React.FC<{children:any,alt?:boolean}> = ({children,alt})=>(
 <View style={{
   backgroundColor:alt?"#0f0a11":"#14090b",
   borderRadius:12,padding:12,marginBottom:10,
   borderWidth:1,borderColor:alt?"#2b1233":"#2a0e14"
 }}>{children}</View>
);
const Row:React.FC<{l:string;r:string|number;c?:string}> = ({l,r,c="#e8e6e3"})=>(
 <View style={{flexDirection:"row",justifyContent:"space-between",marginBottom:6}}>
   <Text style={{color:"#c9c6c2"}}>{l}</Text>
   <Text style={{color:c,fontWeight:"700"}}>{String(r)}</Text>
 </View>
);

/* ─── KAD: RAHASIA HURUF ─── */
const ProfilHurufCard:ExplainAdapter={
 id:"profil-huruf",
 label:"Profil — Asrār al-Ḥurūf (al-Būnī)",
 render(input:Input){
   const nama=(input as any).namaJawi||"";
   const huruf=letters(nama);
   if(!huruf.length) return(
     <Accordion title="Profil — Asrār al-Ḥurūf (al-Būnī)">
       <Box><Text style={{color:"#ffb4b8"}}>Nama Jawi belum diisi.</Text></Box>
     </Accordion>
   );

   const awal=huruf[0], akhir=huruf[huruf.length-1];
   const infoAwal=RULES_AWAL.find(r=>r.h===awal);
   const infoAkhir=RULES_AWAL.find(r=>r.h===akhir);
   const count:Record<string,number>={};
   for(const h of huruf) count[h]=(count[h]||0)+1;

   const ulang=Object.keys(RULES_ULANG).filter(k=>(count[k]||0)>=2);
   const jarang=Object.keys(RULES_JARANG).filter(k=>(count[k]||0)===0);

   return(
     <Accordion title="Profil — Asrār al-Ḥurūf (al-Būnī)">
       <Box>
         <Row l="Nama" r={huruf.join("")} c="#ff4d57"/>
         <Row l="Huruf Awal" r={awal}/>
         <Row l="Huruf Akhir" r={akhir}/>
       </Box>

       <Box>
         <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Huruf Awal</Text>
         <Text style={{color:"#ff4d57",fontWeight:"700"}}>{infoAwal?.judul||"Neutral"}</Text>
         <Text style={{color:"#c9c6c2"}}>{infoAwal?.maksud||"Tiada tafsiran khusus."}</Text>
       </Box>

       <Box alt>
         <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Huruf Akhir</Text>
         <Text style={{color:"#ff4d57",fontWeight:"700"}}>{infoAkhir?.judul||"Neutral"}</Text>
         <Text style={{color:"#c9c6c2"}}>{infoAkhir?.maksud||"Tiada tafsiran khusus."}</Text>
       </Box>

       <Box>
         <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Huruf Ulang</Text>
         {ulang.length?ulang.map(h=>
           <Text key={h} style={{color:"#c9c6c2"}}>• {h} — {RULES_ULANG[h]}</Text>
         ):<Text style={{color:"#c9c6c2"}}>Tiada huruf berulang menonjol.</Text>}
       </Box>

       <Box alt>
         <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Huruf Jarang</Text>
         {jarang.length?jarang.map(h=>
           <Text key={h} style={{color:"#c9c6c2"}}>• {h} — {RULES_JARANG[h]}</Text>
         ):<Text style={{color:"#c9c6c2"}}>Tiada huruf jarang.</Text>}
       </Box>

       <Box>
         <Text style={{color:"#9a9692",fontSize:12}}>
           Tafsiran berpunca daripada simbolik akhlaq al-Būnī; bukan ramalan, tapi cermin kecenderungan watak.
         </Text>
       </Box>
     </Accordion>
   );
 }
};
export default ProfilHurufCard;
