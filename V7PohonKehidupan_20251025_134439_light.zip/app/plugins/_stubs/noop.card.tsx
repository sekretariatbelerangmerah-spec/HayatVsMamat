import React from "react";
import { View } from "react-native";
export default function NoopCard(){ return <View />; }
