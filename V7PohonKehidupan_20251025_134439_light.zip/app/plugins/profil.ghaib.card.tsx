import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/** Util */
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;
const clamp = (n:number, lo:number, hi:number) => Math.max(lo, Math.min(hi, n));

/** Matriks Ghaib — berinspirasikan susunan unsur/planet/burj klasik,
 *  tetapi dipersembahkan secara beradab (wiqāyah/adab), bukan ritual.
 */
const UNSUR = [
  { k:1, n:"Api — Hijab Ego",    m:"Panas & daya pecah halangan; kawal takabbur, kuatkan tawaduk." },
  { k:2, n:"Angin — Lintasan",   m:"Idea/mimpi deras; tapis bisikan, disiplinkan zikir pagi-petang." },
  { k:3, n:"Air — Serapan Hati", m:"Mudah menyerap emosi; bentengkan simpati dengan batas & doa." },
  { k:4, n:"Tanah — Amanah",     m:"Stabil & menanggung; adab rezeki & hak makhluk jadi pagar ghaib." },
] as const;

const PLANET = [
  { k:1, n:"Zuhal — Ujian",      m:"Penyempitan sebagai pembersihan; sabar & tertib, jangan buka aib." },
  { k:2, n:"Musytari — Futuh",   m:"Luaskan ilmu & rezeki; syukuri, elak riya’ karamah." },
  { k:3, n:"Marikh — Sengketa",  m:"Konfrontasi halus; redakan dengan wudhu’ & istighfar." },
  { k:4, n:"Matahari — Nur Nama",m:"Karisma/pamer; jaga niat & elak menunjuk." },
  { k:5, n:"Zuhrah — Tarikan",   m:"Halwah/cinta; jaga batas & kesucian." },
  { k:6, n:"Utarid — Kalam",     m:"Janji & tulisan sebagai amanah; teliti lafaz, elak fitnah." },
  { k:7, n:"Bulan — Cermin Hati",m:"Mudah ‘terkena’; hidupkan pelindung, tidur berwudhu’." },
] as const;

const BURJ = [
  { k:1,  n:"Hamal — Pintu Permulaan",   u:"Api",   m:"Mulakan dengan isti'ādzah; elak terburu." },
  { k:2,  n:"Thawr — Pintu Ikatan",      u:"Tanah", m:"Istiqamah walau sibuk; jangan putus wirid." },
  { k:3,  n:"Jawza — Pintu Lintasan",    u:"Angin", m:"Saring bisikan; rujuk guru bila ragu." },
  { k:4,  n:"Sartan — Pintu Rumah",      u:"Air",   m:"Harmoni rumah; hidupkan al-Baqarah." },
  { k:5,  n:"Asad — Pintu Kepimpinan",   u:"Api",   m:"Kuasa untuk khidmat; elak ujub." },
  { k:6,  n:"Sumbulah — Pintu Tertib",   u:"Tanah", m:"Tertib wudhu’, solat & zikir — pagar ghaib." },
  { k:7,  n:"Mizan — Pintu Hak",         u:"Angin", m:"Adil pada hak orang; jauhi zalim halus." },
  { k:8,  n:"Aqrab — Pintu Sirr",        u:"Air",   m:"Rahsiakan amal; jauhi permainan khadam." },
  { k:9,  n:"Qaws — Pintu Safar",        u:"Api",   m:"Amal musafir & doa; jauhi tempat makruh." },
  { k:10, n:"Jadi — Pintu Taklif",       u:"Tanah", m:"Beban tanggungjawab; mohon ‘awn (pertolongan)." },
  { k:11, n:"Dalw — Pintu Jamaah",       u:"Angin", m:"Khidmat masyarakat; elak fitnah." },
  { k:12, n:"Hut — Pintu Penutupan",     u:"Air",   m:"Tutup majlis dengan doa kafarat; simpan adab." },
] as const;

const fasa30 = (b:number)=>{
  const v = Math.trunc(b) || 30;
  if (v<=10) return { tahap:"Pembukaan", saran:"Mantapkan wirid asas (istighfar, selawat, 3 Qul). Pendedahan boleh, tapi jaga niat." };
  if (v<=20) return { tahap:"Ujian",     saran:"Tambah pelindung; jaga adab makan/tidur/janji, elak pergeseran." };
  return         { tahap:"Penutupan", saran:"Kurangkan pendedahan; fokus malam & muhasabah; kemaskan hutang/urusan." };
};

/** Corak gabungan untuk isyarat lebih “tepat” tanpa menambah props baru */
function polaIsyarat(mod4:number, mod7:number, mod12:number){
  const u = mod4, p = mod7, b = mod12;
  const flags:string[] = [];
  // Contoh pola “panas”: Api × Marikh × Hamal/Asad
  if (u===1 && p===3 && (b===1 || b===5)) {
    flags.push("Panas/konfrontasi halus — sejukkan dengan wudhu’, kurangi debat, amal istighfar 100×.");
  }
  // “Lintasan berat”: Angin × Bulan × Jawza/Dalw
  if (u===2 && p===7 && (b===3 || b===11)) {
    flags.push("Lintasan & mimpi aktif — catat, tapis dengan isti'ādzah; elak ‘mengikut rasa’ tanpa dalil.");
  }
  // “Serapan emosi”: Air × Zuhrah × Sartan/Hut
  if (u===3 && p===5 && (b===4 || b===12)) {
    flags.push("Serapan emosi — jaga sempadan empati; baca al-Baqarah di rumah, perbanyakkan doa pelindung.");
  }
  // “Taklif berat”: Tanah × Zuhal × Thawr/Jadi
  if (u===4 && p===1 && (b===2 || b===10)) {
    flags.push("Taklif/amanah berat — sabar tertib; jangan buka aib, kemaskan perjanjian & hutang.");
  }
  // fallback jika tiada pola khas
  if (!flags.length) flags.push("Status ghaib seimbang — kekalkan adab asas & wirid pelindung harian.");
  return flags;
}

/** UI helpers */
const Box: React.FC<{children:any, alt?:boolean}> = ({children, alt}) => (
  <View style={{
    backgroundColor: alt? "#0e0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2b1233" : "#2a0e14"
  }}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#e8e6e3", opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

/** PROFIL HAYAT — Sudut Ghaib (ala Shams), tanpa ritual, fokus wiqāyah/adab */
const ProfilGhaibCard: ExplainAdapter = {
  id: "profil-ghaib",
  label: "Penjelasan — Profil Hayat (Sudut Ghaib)",
  render(input: Input) {
    const aIsteri = input.aIsteri||0;
    const aAnak   = input.aAnakJumlah||0;
    const tawafiq = (input.aDiri||0)+(input.aIbu||0)+aIsteri+aAnak; // ikut yang sedia ada (tanpa bulan)
    const m4  = modWrap(tawafiq,4);
    const m7  = modWrap(tawafiq,7);
    const m12 = modWrap(tawafiq,12);
    const b30 = (tawafiq % 30) || 30;

    const U = UNSUR.find(x=>x.k===m4)!;
    const P = PLANET.find(x=>x.k===m7)!;
    const B = BURJ.find(x=>x.k===m12)!;
    const F = fasa30(b30);
    const flags = polaIsyarat(m4, m7, m12);

    return (
      <Accordion title="Penjelasan — Profil Hayat (Sudut Ghaib)">
        {/* Ringkasan angka */}
        <Box>
          <Row l="Tawāfiq (Jumlah Abjad)" r={tawafiq} c="#ff4d57" />
          <Row l="Baki 30" r={b30} c="#ff4d57" />
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Nota: Sudut ghaib menggunakan jumlah abjad tanpa faktor bulan; kekal selari logik Shams yang asal.
          </Text>
        </Box>

        {/* Unsur / Planet / Burj */}
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Isyarat Unsur</Text>
          <Row l="Unsur" r={U.n} />
          <Text style={{color:"#c9c6c2"}}>{U.m}</Text>
        </Box>
        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Isyarat Planet</Text>
          <Row l="Planet" r={P.n} />
          <Text style={{color:"#c9c6c2"}}>{P.m}</Text>
        </Box>
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Isyarat Burj</Text>
          <Row l="Burj" r={`${B.n} (${B.u})`} />
          <Text style={{color:"#c9c6c2"}}>{B.m}</Text>
        </Box>

        {/* Fasa & Wiqayah */}
        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Fasa — Baki 30</Text>
          <Text style={{color:"#e8e6e3"}}>{F.tahap}: {F.saran}</Text>
        </Box>

        {/* Pola gabungan (lebih “tepat”) */}
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Isyarat Gabungan</Text>
          {flags.map((t, i)=>(
            <Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>
          ))}
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Garis panduan ghaib bersifat pelindung & adab; jauhi amalan memanggil makhluk/khadam & ritual tanpa guru.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ProfilGhaibCard;
