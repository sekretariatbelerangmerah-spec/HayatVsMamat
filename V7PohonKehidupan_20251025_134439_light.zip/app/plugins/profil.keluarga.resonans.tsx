import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/**
 * Tafsiran Tawāfiq Keluarga (Resonans)
 * -----------------------------------------
 * Menggabungkan abjad diri, ibu, isteri & anak (jumlah 1–12)
 * untuk melihat pola dinamik (gelombang unsur).
 * Hasil memberi:
 * - Keseimbangan unsur (api/angin/air/tanah)
 * - Peranan dominan setiap ahli
 * - Nasihat komunikasi & adab keluarga
 */

// util asas
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

// warna & gaya
const colors = {
  bg:"#14090b", border:"#2a0e14", text:"#e8e6e3", accent:"#ff4d57", sub:"#0f0a0b"
};

const Box: React.FC<{children:any,alt?:boolean}> = ({children,alt}) => (
  <View style={{
    backgroundColor: alt? colors.sub : colors.bg,
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#351920" : colors.border
  }}>
    {children}
  </View>
);

const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c=colors.text}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:colors.text, opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

// tafsiran unsur
const UNSUR = {
  1:{nama:"Api",   peranan:"Pemula",   saran:"Mulakan perubahan dengan hikmah, elak mendesak."},
  2:{nama:"Angin", peranan:"Pemikir",  saran:"Gunakan kata & idea membina, jangan terlampau sinis."},
  3:{nama:"Air",   peranan:"Pendamai", saran:"Sejukkan suasana; jaga emosi & doa keluarga."},
  4:{nama:"Tanah", peranan:"Penstabil",saran:"Pegang amanah; urus kewangan & jadual rumah tangga."},
} as const;

const Bar = ({label,val}:{label:string;val:number}) => (
  <View style={{marginBottom:6}}>
    <Text style={{color:colors.text}}>{label}</Text>
    <View style={{height:8, backgroundColor:colors.sub, borderRadius:6}}>
      <View style={{height:8, width:`${Math.min(100,Math.max(0,val))}%`, backgroundColor:colors.accent, borderRadius:6}} />
    </View>
  </View>
);

const calcUnsur = (total:number) => modWrap(total,4);
const labelAhli = (i:number) => i===0?"Diri": i===1?"Ibu": i===2?"Isteri": `Anak ${i-2}`;

const ProfilKeluargaResonans: ExplainAdapter = {
  id: "keluarga-resonans",
  label: "Tawāfiq Keluarga — Resonans & Dinamika",
  render(input: Input) {
    const list = [
      input.aDiri||0,
      input.aIbu||0,
      input.aIsteri||0,
      ...(Array.isArray(input.aAnak)? input.aAnak : []),
    ].filter(v=>v>0);

    const unsurs = list.map(v=>calcUnsur(v));
    const kiraan = [0,0,0,0];
    unsurs.forEach(u=>kiraan[u-1]++);
    const totalAhli = list.length || 1;
    const peratus = kiraan.map(k=>Math.round((k/totalAhli)*100));

    // cari dominan
    const maxU = kiraan.indexOf(Math.max(...kiraan))+1;
    const utama = UNSUR[maxU as 1|2|3|4];

    // tafsiran komunikasi
    const tipsKom = {
      1:"Jika ramai berunsur Api → pastikan ruang mendengar. Jangan semua mahu memimpin.",
      2:"Jika ramai berunsur Angin → banyak idea tapi cepat bosan. Tetapkan struktur.",
      3:"Jika ramai berunsur Air → harmoni tapi mudah pasif. Lantik ketua keluarga jelas.",
      4:"Jika ramai berunsur Tanah → stabil tapi berat berubah. Galak ekspresi & variasi."
    }[maxU];

    // amaran umum
    const amaran = {
      1:"Amaran: ego & perbalahan cepat membara.",
      2:"Amaran: kecelaruan kata & janji palsu.",
      3:"Amaran: serapan emosi & murung senyap.",
      4:"Amaran: kaku dan jarang berkomunikasi terbuka."
    }[maxU];

    return (
      <Accordion title="Tawāfiq Keluarga — Resonans & Dinamika">
        <Box>
          <Text style={{color:colors.text, fontWeight:"800", marginBottom:8}}>
            Unsur Dominan Keluarga: <Text style={{color:colors.accent}}>{utama.nama}</Text> ({utama.peranan})
          </Text>
          <Bar label="Api (Pemula)" val={peratus[0]} />
          <Bar label="Angin (Pemikir)" val={peratus[1]} />
          <Bar label="Air (Pendamai)" val={peratus[2]} />
          <Bar label="Tanah (Penstabil)" val={peratus[3]} />
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Nisbah berdasarkan {totalAhli} ahli keluarga.
          </Text>
        </Box>

        <Box alt>
          <Text style={{color:colors.text, fontWeight:"800", marginBottom:6}}>Peranan Individu</Text>
          {unsurs.map((u,i)=>(
            <Text key={i} style={{color:"#c9c6c2", marginBottom:3}}>
              {labelAhli(i)} — {UNSUR[u as 1|2|3|4].peranan} ({UNSUR[u as 1|2|3|4].nama})
            </Text>
          ))}
        </Box>

        <Box>
          <Text style={{color:colors.text, fontWeight:"800", marginBottom:6}}>Nasihat Komunikasi</Text>
          <Text style={{color:"#c9c6c2", marginBottom:4}}>{utama.saran}</Text>
          <Text style={{color:"#c9c6c2"}}>{tipsKom}</Text>
        </Box>

        <Box alt>
          <Text style={{color:"#ff4d57", fontWeight:"800", marginBottom:6}}>Isyarat & Amaran</Text>
          <Text style={{color:"#c9c6c2"}}>{amaran}</Text>
        </Box>

        <Text style={{color:"#9a9692", marginTop:8, fontSize:12}}>
          Tafsiran berdasarkan corak unsur Shams al-Maʿārif. 
          Bertujuan menilai keseimbangan emosi & peranan, bukan menilai “baik-buruk”.
        </Text>
      </Accordion>
    );
  }
};
export default ProfilKeluargaResonans;
