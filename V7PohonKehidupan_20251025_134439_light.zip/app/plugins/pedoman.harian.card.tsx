import React, { useEffect, useMemo, useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter } from "../adapters/types";

/* ===== UI helpers (gaya kad) ===== */
const Box: React.FC<{alt?:boolean; children:any}> = ({alt, children}) => (
  <View style={{
    backgroundColor: alt ? "#0f0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2a1230" : "#2a0e14"
  }}>{children}</View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#c9c6c2"}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);
const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color}) => (
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

/* ===== Model pedoman ===== */
type Warna = "Hijau"|"Putih"|"Kuning"|"Merah"|"Hitam";
type BlokMasa = "Pagi"|"Siang"|"Tengah"|"Zuhur"|"Asar"|"Maghrib"|"Malam";

const BLOK_JAM_MY: Record<Exclude<BlokMasa,"Maghrib"|"Malam">,[string,string]> = {
  Pagi:   ["06:00","08:30"],
  Siang:  ["08:30","10:30"],
  Tengah: ["11:00","12:00"],
  Zuhur:  ["12:30","16:00"],
  Asar:   ["16:00","18:00"],
};

/** Grid warna 1..30 → {Pagi,Siang,Tengah,Zuhur,Asar} */
const PEDOMAN: Record<number, Record<Exclude<BlokMasa,"Maghrib"|"Malam">,Warna>> = (() => {
  const seqs: Warna[][] = [
    ["Kuning","Hitam","Putih","Merah","Hijau"], // d=1
    ["Hijau","Kuning","Hitam","Putih","Merah"], // d=2
    ["Merah","Hijau","Kuning","Hitam","Putih"], // d=3
    ["Putih","Merah","Hijau","Kuning","Hitam"], // d=4
    ["Hitam","Putih","Merah","Hijau","Kuning"], // d=5
  ];
  const days: Record<number, Record<Exclude<BlokMasa,"Maghrib"|"Malam">,Warna>> = {};
  for (let d=1; d<=30; d++){
    const row = seqs[(d-1)%5];
    const [Pagi,Siang,Tengah,Zuhur,Asar] = row;
    days[d] = { Pagi, Siang, Tengah, Zuhur, Asar };
  }
  return days;
})();

const labelWarna: Record<Warna,string> = {
  Hijau:"REZEKI — masa terbaik bergerak/urus peluang.",
  Putih:"TENANG — neutral, sesuai runding & susun kerja.",
  Kuning:"WASPADA — jalan ada halangan kecil, bergerak cermat.",
  Merah:"SELAMAT — baik untuk urusan asas & keluarga.",
  Hitam:"HALANGAN — tunda jika boleh; banyakkan doa & perlindungan.",
};
const colorWarna: Record<Warna,string> = {
  Hijau:"#39d98a", Putih:"#e8e6e3", Kuning:"#ffd166", Merah:"#ff4d57", Hitam:"#222"
};

/* ===== Util masa ===== */
function toMin(s:string){ const [H,M]=s.split(":").map(Number); return H*60+M; }
function nowMYMinutes(){
  const t = new Date(); // anggap peranti di MYT atau ikut jam sistem
  return t.getHours()*60 + t.getMinutes();
}
function blokSemasa24(mins:number): BlokMasa {
  if (mins >= toMin("21:00") || mins < toMin("06:00")) return "Malam";
  if (mins >= toMin("18:00") && mins < toMin("21:00")) return "Maghrib";
  for (const b of ["Pagi","Siang","Tengah","Zuhur","Asar"] as const){
    const [a,z]=BLOK_JAM_MY[b];
    if (mins>=toMin(a) && mins<toMin(z)) return b;
  }
  return "Asar"; // fallback
}
const wrap30 = (n:number)=> ((n-1)%30+30)%30 + 1;

/* Warna untuk sesuatu blok:
   - Pagi..Asar: ikut PEDOMAN[day][blok]
   - Maghrib: sama dengan “Pagi” hari semasa
   - Malam:   sama dengan “Siang” hari semasa */
function warnaUntuk(day:number, blok:BlokMasa): Warna {
  const key = wrap30(day);
  const row = PEDOMAN[key];
  if (!row) return "Putih";
  if (blok==="Maghrib") return row["Pagi"];
  if (blok==="Malam")   return row["Siang"];
  return row[blok];
}

/* ===== Kad ===== */
const CardPedomanHarian: ExplainAdapter = {
  id: "pedoman-harian-auto",
  label: "Pedoman Harian 24-Jam — Manual Hijri + Offset + Maghrib (Auto Jam MY)",
  render(){
    // input
    const [hijriRaw, setHijriRaw] = useState<string>(""); // 1..30 (manual)
    const [offset, setOffset] = useState<number>(0);      // -2..+2
    const [startMaghrib, setStartMaghrib] = useState<boolean>(true);

    // auto tick setiap 30s
    const [, setTick] = useState(0);
    useEffect(()=>{
      const id = setInterval(()=>setTick(x=>x+1), 30_000);
      return ()=>clearInterval(id);
    },[]);

    // kira hari terpakai
    const minutes = nowMYMinutes();
    const base = Math.max(1, Math.min(30, Math.trunc(Number(hijriRaw||"1"))));
    const afterMaghrib = minutes >= toMin("18:00");
    const dayApplied = useMemo(()=>{
      const bump = startMaghrib && afterMaghrib ? 1 : 0;
      return wrap30(base + offset + bump);
    },[base, offset, startMaghrib, afterMaghrib]);

    const blok = blokSemasa24(minutes);
    const warna = warnaUntuk(dayApplied, blok);

    const now = new Date();
    const hh = String(now.getHours()).padStart(2,"0");
    const mm = String(now.getMinutes()).padStart(2,"0");

    const setOffsetSafe=(v:number)=> setOffset(Math.max(-2,Math.min(2,Math.trunc(v||0))));

    const blokJam24: Record<BlokMasa,string> = {
      Pagi:   `${BLOK_JAM_MY.Pagi[0]}–${BLOK_JAM_MY.Pagi[1]}`,
      Siang:  `${BLOK_JAM_MY.Siang[0]}–${BLOK_JAM_MY.Siang[1]}`,
      Tengah: `${BLOK_JAM_MY.Tengah[0]}–${BLOK_JAM_MY.Tengah[1]}`,
      Zuhur:  `${BLOK_JAM_MY.Zuhur[0]}–${BLOK_JAM_MY.Zuhur[1]}`,
      Asar:   `${BLOK_JAM_MY.Asar[0]}–${BLOK_JAM_MY.Asar[1]}`,
      Maghrib:"18:00–21:00",
      Malam:  "21:00–06:00",
    };

    const urut: BlokMasa[] = ["Pagi","Siang","Tengah","Zuhur","Asar","Maghrib","Malam"];

    return (
      <Accordion title="Pedoman Harian 24-Jam — Manual Hijri + Offset + Maghrib (Auto Jam MY)">
        {/* Input */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Input</Text>

          <Text style={{color:"#e8e6e3"}}>Tarikh Hijri (1–30)</Text>
          <TextInput
            value={hijriRaw}
            onChangeText={setHijriRaw}
            placeholder="cth: 12"
            keyboardType="number-pad"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}}
          />

          <Text style={{color:"#e8e6e3"}}>Offset Hijri (−2…+2)</Text>
          <TextInput
            value={String(offset)}
            onChangeText={(t)=>setOffsetSafe(Number(t))}
            placeholder="cth: 0"
            keyboardType="numbers-and-punctuation"
            placeholderTextColor="#777"
            style={{color:"#e8e6e3",borderColor:"#2a0e14",borderWidth:1,borderRadius:8,padding:8,marginBottom:8}}
          />

          <View style={{flexDirection:"row", alignItems:"center", marginTop:6}}>
            <Chip
              label={`Mula hari pada Maghrib ${startMaghrib?"(YA)":"(TIDAK)"}`}
              active={startMaghrib}
              onPress={()=>setStartMaghrib(v=>!v)}
              color="#888"
            />
          </View>

          <TouchableOpacity onPress={()=>{ setHijriRaw(""); setOffset(0); setStartMaghrib(true); }}>
            <Text style={{color:"#9a9692",textDecorationLine:"underline",marginTop:8}}>Kosongkan</Text>
          </TouchableOpacity>

          <Text style={{color:"#9a9692",marginTop:8,fontSize:12}}>
            *Jika Malaysia lambat/awal 1 hari berbanding rujukan lain, guna “Offset Hijri”.
            Jika nak ikut kaedah “hari bermula selepas Maghrib”, ON-kan toggle di atas.
          </Text>
        </Box>

        {/* Status semasa */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Status Sekarang (Auto Mengikut Jam MY)</Text>
          <Row l="Jam sekarang" r={`${hh}:${mm} (MY)`} />
          <Row l="Hari terpakai (1–30)" r={dayApplied} />
          <Row l="Blok waktu" r={`${blok} (${blokJam24[blok]})`} />
          <Row l="Warna" r={warna} c={colorWarna[warna]} />
          <Text style={{color:"#c9c6c2", marginTop:6}}>• {labelWarna[warna]}</Text>
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Kad auto refresh setiap 30 saat & akan tukar warna bila melintas blok seterusnya.
          </Text>
        </Box>

        {/* Jadual penuh 24 jam untuk hari terpakai */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:6}}>Jadual Warna — Hari {dayApplied}</Text>
          {urut.map((b)=>(
            <View key={b} style={{flexDirection:"row", justifyContent:"space-between", paddingVertical:6, borderBottomColor:"#2a0e14", borderBottomWidth:1}}>
              <Text style={{color:"#c9c6c2"}}>{b} ({blokJam24[b]})</Text>
              <Text style={{color: colorWarna[warnaUntuk(dayApplied, b)], fontWeight:"700"}}>{warnaUntuk(dayApplied, b)}</Text>
            </View>
          ))}
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Warna: Hijau=Rezeki · Putih=Tenang · Kuning=Waspada · Merah=Selamat · Hitam=Halangan.
          </Text>
        </Box>
      </Accordion>
    );
  }
};

export default CardPedomanHarian;
