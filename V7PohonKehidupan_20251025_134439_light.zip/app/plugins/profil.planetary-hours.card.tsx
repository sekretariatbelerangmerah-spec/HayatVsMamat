import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

// Pemetaan hari (1–7) → planet penguasa hari (tradisi klasik)
const DAYS = {
  1: { hari:"Ahad",   planet:"Matahari (Shams)",   akhlak:["Wibawa", "Keyakinan"], risiko:["Pamer", "Ujub"], saran:["Niat khidmat", "Elak menunjuk"] },
  2: { hari:"Isnin",  planet:"Bulan (Qamar)",      akhlak:["Empati", "Intuisi"],   risiko:["Mood turun-naik"], saran:["Stabilkan rutin", "Tidur berwudhu’"] },
  3: { hari:"Selasa", planet:"Marikh",             akhlak:["Berani", "Tegas"],     risiko:["Ganas/konflik"], saran:["Sejukkan dengan wudhu’", "Elak debat"] },
  4: { hari:"Rabu",   planet:"Utarid (Mercury)",   akhlak:["Akal", "Tulisan"],     risiko:["Cakap berlebihan"], saran:["Teliti lafaz", "Dokumentasi"] },
  5: { hari:"Khamis", planet:"Musytari (Jupiter)", akhlak:["Luas ilmu", "Rezeki"], risiko:["Boros/riya’"], saran:["Syukur", "Urus amanah"] },
  6: { hari:"Jumaat", planet:"Zuhrah (Venus)",     akhlak:["Kasih", "Harmoni"],    risiko:["Lalai/hawa"], saran:["Jaga batas", "Maaf-memaaf"] },
  7: { hari:"Sabtu",  planet:"Zuhal (Saturn)",     akhlak:["Sabar", "Tertib"],     risiko:["Murung/sempit"], saran:["Istighfar", "Jangan buka aib"] },
} as const;

const Box: React.FC<{children:any}> = ({children}) => (
  <View style={{backgroundColor:"#0f0a0b", borderRadius:12, padding:12, marginBottom:10, borderWidth:1, borderColor:"#251216"}}>
    {children}
  </View>
);

const ProfilPlanetaryHoursCard: ExplainAdapter = {
  id: "planetary-hours",
  label: "Profil — Saʿāt Kawākib (Hari Planet)",
  render({ hariLahir = 0 }: Input) {
    const idx = ((Math.trunc(hariLahir)-1+7)%7)+1 as 1|2|3|4|5|6|7;
    const info = DAYS[idx];
    return (
      <Accordion title="Profil — Saʿāt Kawākib (Hari Planet)">
        <Box>
          <Text style={{color:"#e8e6e3"}}>Hari Lahir: <Text style={{fontWeight:"800", color:"#ff4d57"}}>{info.hari}</Text></Text>
          <Text style={{color:"#e8e6e3"}}>Penguasa Hari: <Text style={{fontWeight:"800", color:"#ff4d57"}}>{info.planet}</Text></Text>
        </Box>
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Akhlak Disaran</Text>
          {info.akhlak.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
        </Box>
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Risiko</Text>
          {info.risiko.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
        </Box>
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800"}}>Saran Adab</Text>
          {info.saran.map((t,i)=>(<Text key={i} style={{color:"#c9c6c2"}}>{`\u2022 ${t}`}</Text>))}
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Nota: Ini pembacaan simbolik/bersejarah—bukan pemilihan waktu amal.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ProfilPlanetaryHoursCard;
