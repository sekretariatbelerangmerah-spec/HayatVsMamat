import React, { useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

const modWrap = (n:number, base:number)=>((Math.trunc(n)-1)%base+base)%base+1;

type BI = {
  k:number; nama:string; unsur:"Api"|"Tanah"|"Angin"|"Air";
  planet:string; warna:string; logam:string;
  kataKunci:string[]; kekuatan:string; risiko:string; saran:string;
  serasi:string; lawan:string;
};

const B:BI[] = [
  {k:1,nama:"Hamal",unsur:"Api",planet:"Marikh",warna:"merah",logam:"besi",
   kataKunci:["Pemula","Berani"],kekuatan:"Tindakan pantas",risiko:"Gopoh",saran:"Rancang dahulu; dengar nasihat.",serasi:"Asad, Qaws",lawan:"Mizan"},
  {k:2,nama:"Thawr",unsur:"Tanah",planet:"Zuhrah",warna:"hijau tanah",logam:"tembaga",
   kataKunci:["Stabil","Sabar"],kekuatan:"Konsisten & setia",risiko:"Degil",saran:"Fleksibel bila perlu.",serasi:"Sumbulah, Jadi",lawan:"Aqrab"},
  {k:3,nama:"Jawza",unsur:"Angin",planet:"Utarid",warna:"kuning",logam:"merkuri",
   kataKunci:["Petah","Intelek"],kekuatan:"Komunikasi",risiko:"Berselerak info",saran:"Fokus satu topik.",serasi:"Mizan, Dalw",lawan:"Sartan"},
  {k:4,nama:"Sartan",unsur:"Air",planet:"Bulan",warna:"perak",logam:"perak",
   kataKunci:["Emosi","Rumah"],kekuatan:"Empati & jagaan",risiko:"Terlalu sensitif",saran:"Jaga tidur & ritma.",serasi:"Aqrab, Hut",lawan:"Jawza"},
  {k:5,nama:"Asad",unsur:"Api",planet:"Matahari",warna:"emas",logam:"emas",
   kataKunci:["Kepimpinan"],kekuatan:"Karismatik",risiko:"Ego/over pamer",saran:"Pimpin beradab.",serasi:"Hamal, Qaws",lawan:"Dalw"},
  {k:6,nama:"Sumbulah",unsur:"Tanah",planet:"Utarid",warna:"zaitun",logam:"plumbum",
   kataKunci:["Teliti"],kekuatan:"Kualiti kerja",risiko:"Perfeksionis",saran:"Bezakan perlu vs ideal.",serasi:"Thawr, Jadi",lawan:"Qaws"},
  {k:7,nama:"Mizan",unsur:"Angin",planet:"Zuhrah",warna:"biru muda",logam:"tembaga",
   kataKunci:["Adil","Diplomasi"],kekuatan:"Pendamai",risiko:"Ragu",saran:"Putus cepat, maklumat cukup.",serasi:"Jawza, Dalw",lawan:"Hamal"},
  {k:8,nama:"Aqrab",unsur:"Air",planet:"Marikh",warna:"ungu",logam:"besi",
   kataKunci:["Rahsia","Transformasi"],kekuatan:"Fokus mendalam",risiko:"Cemburu/keras",saran:"Rahsiakan amal; lembutkan nada.",serasi:"Sartan, Hut",lawan:"Thawr"},
  {k:9,nama:"Qaws",unsur:"Api",planet:"Musytari",warna:"indigo",logam:"tin",
   kataKunci:["Falsafah","Safar"],kekuatan:"Visi & ilmu luas",risiko:"Over janji",saran:"Kecilkan target.",serasi:"Asad, Hamal",lawan:"Sumbulah"},
  {k:10,nama:"Jadi",unsur:"Tanah",planet:"Zuhal",warna:"kelabu",logam:"plumbum",
   kataKunci:["Struktur","Tanggungjawab"],kekuatan:"Disiplin",risiko:"Kaku/keras",saran:"Tambah empati.",serasi:"Sumbulah, Thawr",lawan:"Hut"},
  {k:11,nama:"Dalw",unsur:"Angin",planet:"Uranus/Saturn",warna:"turquoise",logam:"aloi",
   kataKunci:["Inovasi","Komuniti"],kekuatan:"Reformasi",risiko:"Eksentrik",saran:"Uji kecil dulu.",serasi:"Mizan, Jawza",lawan:"Asad"},
  {k:12,nama:"Hut",unsur:"Air",planet:"Neptun/Musytari",warna:"biru laut",logam:"perak",
   kataKunci:["Spiritual","Kasih"],kekuatan:"Penyembuh",risiko:"Kabur sempadan",saran:"Tetapkan batas.",serasi:"Sartan, Aqrab",lawan:"Jadi"}
];

const UNSUR_INFO: Record<BI["unsur"], string> = {
  Api:   "Tenaga permulaan, keberanian, laju bertindak; kawal panas baran & ego.",
  Tanah: "Stabil, sabar, bina asas; elak terlalu kaku & terlebih berhati-hati.",
  Angin: "Idea, komunikasi, jaringan; lawan berselerak dengan fokus & catatan.",
  Air:   "Empati, penjagaan, intuisi; perlu sempadan emosi & ritma tidur baik."
};

const PLANET_INFO: Record<string, string> = {
  Marikh: "Daya juang, konfrontasi; dinginkan dengan wudhu’ & sabar.",
  Zuhrah: "Harmoni, seni, kasih; jaga batas & elak memanja berlebihan.",
  Utarid: "Akal & kalam; teliti fakta, jangan gopoh menyebar.",
  Bulan: "Emosi & rumah; jaga tidur & suasana aman.",
  Matahari: "Syuhrah & kepimpinan; pimpin beradab, kawal pamer.",
  Musytari: "Futuh ilmu & rezeki; syukuri & urus komitmen.",
  Zuhal: "Ujian, disiplin; sabar tertib, kemas hutang/amanah.",
  "Uranus/Saturn": "Reformasi terkawal; inovasi + tertib, jangan goncang semuanya.",
  "Neptun/Musytari": "Ilham rohani + keluasan; pastikan sempadan jelas & realistik."
};

const colorByUnsur=(u:BI["unsur"])=>u==="Api"?"#ff4d57":u==="Tanah"?"#b48b5a":u==="Angin"?"#77c0ff":"#7bd1c9";

const Chip:React.FC<{label:string;active:boolean;onPress:()=>void;color?:string}> = ({label,active,onPress,color})=>(
  <TouchableOpacity onPress={onPress} style={{
    paddingVertical:6,paddingHorizontal:12,borderRadius:20,
    backgroundColor:active?(color||"#ff4d57"):"transparent",
    borderWidth:1,borderColor:color||"#555",marginRight:8,marginBottom:8
  }}>
    <Text style={{color:active?"#fff":color||"#ccc",fontWeight:"600",fontSize:12}}>{label}</Text>
  </TouchableOpacity>
);

const Box:React.FC<{alt?:boolean;children:any}> = ({alt,children})=>(
  <View style={{
    backgroundColor:alt?"#0f0a10":"#14090b",borderRadius:12,padding:12,marginBottom:10,
    borderWidth:1,borderColor:alt?"#2a1230":"#2a0e14"
  }}>{children}</View>
);

const ProfilBurujCard:ExplainAdapter = {
  id:"profil-buruj",
  label:"Profil — Ensiklopedia Burūj (12 Tanda)",
  render(input:Input){
    const tawafiq=(input.aDiri||0)+(input.aIbu||0)+(input.aIsteri||0)+(input.aAnakJumlah||0);
    const m12=modWrap(tawafiq||0,12);
    const aktif=B.find(x=>x.k===m12)||B[0];

    const [filterUnsur,setFilterUnsur]=useState<string|null>(null);
    const [filterPlanet,setFilterPlanet]=useState<string|null>(null);

    const unsurList:["Api","Tanah","Angin","Air"]=["Api","Tanah","Angin","Air"];
    const planetList=[
      "Marikh","Zuhrah","Utarid","Bulan","Matahari",
      "Musytari","Zuhal","Uranus/Saturn","Neptun/Musytari"
    ];

    let list=B.slice();
    if(filterUnsur) list=list.filter(b=>b.unsur===filterUnsur);
    if(filterPlanet) list=list.filter(b=>b.planet===filterPlanet);

    return(
      <Accordion title="Profil — Ensiklopedia Burūj (12 Tanda)">
        {/* Buruj aktif ikut mod12 */}
        <Box>
          <Text style={{color:"#ff4d57",fontWeight:"800",marginBottom:8}}>Buruj Aktif (mod12)</Text>
          <Text style={{color:"#e8e6e3"}}>{aktif.nama} ({aktif.unsur}) — {aktif.planet}</Text>
          <Text style={{color:"#c9c6c2",marginTop:4}}>{aktif.kekuatan}</Text>
        </Box>

        {/* Tapis + keterangan */}
        <Box alt>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:8}}>Tapis Unsur</Text>
          <View style={{flexDirection:"row",flexWrap:"wrap"}}>
            {unsurList.map(u=>
              <Chip key={u} label={u} color={colorByUnsur(u as any)}
                active={filterUnsur===u} onPress={()=>setFilterUnsur(filterUnsur===u?null:u)}/>
            )}
            <Chip label="Reset" color="#888" active={false}
              onPress={()=>setFilterUnsur(null)} />
          </View>
          {filterUnsur &&
            <Text style={{color:"#c9c6c2",marginTop:6}}>{UNSUR_INFO[filterUnsur as BI["unsur"]]}</Text>
          }

          <Text style={{color:"#e8e6e3",fontWeight:"800",marginVertical:8}}>Tapis Planet</Text>
          <View style={{flexDirection:"row",flexWrap:"wrap"}}>
            {planetList.map(p=>
              <Chip key={p} label={p} color="#8888aa"
                active={filterPlanet===p} onPress={()=>setFilterPlanet(filterPlanet===p?null:p)}/>
            )}
            <Chip label="Reset" color="#888" active={false}
              onPress={()=>setFilterPlanet(null)} />
          </View>
          {filterPlanet &&
            <Text style={{color:"#c9c6c2",marginTop:6}}>{PLANET_INFO[filterPlanet]}</Text>
          }
        </Box>

        {/* Senarai hasil */}
        <Box>
          <Text style={{color:"#e8e6e3",fontWeight:"800",marginBottom:8}}>
            {filterUnsur||filterPlanet?"Hasil Tapisan":"Ensiklopedia 12 Burūj"}
          </Text>

          {list.map(b=>(
            <View key={b.k} style={{marginBottom:10,borderBottomWidth:1,borderBottomColor:"#231015",paddingBottom:8}}>
              <Text style={{color:colorByUnsur(b.unsur),fontWeight:"800"}}>{b.k}. {b.nama} — {b.unsur}</Text>
              <Text style={{color:"#e8e6e3"}}>Planet: {b.planet}</Text>
              <Text style={{color:"#c9c6c2"}}>Kata kunci: {b.kataKunci.join(", ")}</Text>
              <Text style={{color:"#c9c6c2"}}>Kekuatan: {b.kekuatan}</Text>
              <Text style={{color:"#c9c6c2"}}>Risiko: {b.risiko}</Text>
              <Text style={{color:"#c9c6c2"}}>Saran: {b.saran}</Text>
            </View>
          ))}

          {list.length===0 && (
            <Text style={{color:"#9a9692"}}>
              Tiada padanan untuk kombinasi dipilih. Cuba tekan “Reset” pada Unsur/Planet.
            </Text>
          )}
        </Box>
      </Accordion>
    );
  }
};
export default ProfilBurujCard;
