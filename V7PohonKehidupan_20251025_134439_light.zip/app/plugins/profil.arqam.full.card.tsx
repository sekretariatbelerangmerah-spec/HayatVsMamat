import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

/** Util ringkas */
const modWrap = (n:number, base:number)=>((Math.trunc(n)-1)%base+base)%base+1;

/** Jalur besar (band 1–54) — untuk “tone” ghaib */
const BAND = (n:number)=>{
  if (n<=9)   return {nama:"Asal",      maksud:"Benih/permulaan; bina niat & asas yang bersih."};
  if (n<=18)  return {nama:"Bentuk",    maksud:"Pembentukan & tertib; kemaskan struktur & disiplin."};
  if (n<=27)  return {nama:"Luas",      maksud:"Peluasan rezeki/ilmu; urus jaringan & amanah."};
  if (n<=36)  return {nama:"Imbang",    maksud:"Ujian & imbangan; kawal emosi, halalkan hak."};
  if (n<=45)  return {nama:"Ghaibiyyah",maksud:"Hal batin/rahsia zahir-batin; jaga adab & perlindungan."};
  return           {nama:"Warisan",   maksud:"Penutup/pewarisan; susun semula, lepaskan yang selesai."};
};

/** Tafsiran 1–54 (padat — maksud & nasihat amali) */
type Rec = { t:string; m:string; s:string };
const A: Record<number, Rec> = {
  1:{t:"Asal Tauhid",m:"Mula bersih; fokus niat & keesaan.",s:"Tajdid niat; istighfar 100×; mulakan kecil tapi tetap."},
  2:{t:"Dualiti & Tertib",m:"Pasang-pasang; imbang peranan.",s:"Rancang tugas rumah/kerja; elak ekstrem; jaga wudhu’."},
  3:{t:"Gerak & Kalam",m:"Komunikasi, ilmu & jaringan.",s:"Tuliskan perjanjian; dengar lebih; elak debat sia-sia."},
  4:{t:"Asas & Amanah",m:"Bina tapak kukuh; sabar berproses.",s:"Setkan rutin ibadah/kerja; lunasi hutang kecil dahulu."},
  5:{t:"Harmoni & Kasih",m:"Pendamai; seni & akhlak lembut.",s:"Baiki hubungan; maafkan; elak berlebihan hiburan."},
  6:{t:"Tertib Halus",m:"Khidmat teliti; perincian & adab.",s:"Audit kebersihan, jadual & belanja; jangan cerewet."},
  7:{t:"Isyarat Hati",m:"Peka batin, mimpi & keluarga.",s:"Jaga tidur/wudhu’; baca Al-Baqarah di rumah."},
  8:{t:"Ujian Zuhal",m:"Sempit sementara; pembersihan darjat.",s:"Sabar & konsisten; tutup aib; selesai komitmen lama."},
  9:{t:"Penutup Pusingan",m:"Tamat kitaran; bersedia baharu.",s:"Review 90 hari; buang beban; siapkan pelan baru."},
  10:{t:"Mulai Teguh",m:"Permulaan berstruktur.",s:"Dokumentasi proses; delegasi awal; jaga integriti data."},
  11:{t:"Idea & Jaringan",m:"Inovasi komuniti.",s:"Brainstorm; cari rakan pelaksana; kawal ‘over-sharing’."},
  12:{t:"Kitaran Buruj",m:"Irama 12 pintu; masa & tertib.",s:"Bina kalendar 12-bulan; checkpoint bulanan."},
  13:{t:"Transformasi",m:"Ubah bentuk; potong toksik.",s:"Detoks info & emosi; kurangkan aplikasi/mesej tak perlu."},
  14:{t:"Seimbang Hak",m:"Mizan; rundingan adil.",s:"Mediasi isu keluarga/kerja; catat persetujuan."},
  15:{t:"Kasih & Rezeki",m:"Zuhrah; tarik minat & peluang.",s:"Lunak dalam teguh; elak riya’; sedekah rahsia."},
  16:{t:"Tertib & Kualiti",m:"Audit mutu & SOP.",s:"ISO diri: checklist harian; satu peningkatan kecil/ hari."},
  17:{t:"Hati & Keturunan",m:"Rumah/anak; sensitif.",s:"Hadkan drama; keluarga dahulu; matikan notifikasi malam."},
  18:{t:"Pembersihan",m:"Saringan akhir fasa bentuk.",s:"Buang projek beku; tutup akaun/keahlian tak perlu."},
  19:{t:"Pintu Safar",m:"Qaws; keluasan visi.",s:"Eksplorasi ilmu/bisnes; rancang perjalanan berfaedah."},
  20:{t:"Taklif & Struktur",m:"Jadi; tanggungjawab besar.",s:"Tetapkan sempadan kerja; latih pengganti awal."},
  21:{t:"Komuniti",m:"Dalw; khidmat masyarakat.",s:"Sertai pasukan; elak politik; fokus manfaat."},
  22:{t:"Ilham Halus",m:"Hut; empati & spiritual.",s:"Catat mimpi; jangan ikut rasa tanpa dalil/guru."},
  23:{t:"Pelopor Berani",m:"Hamal; mula projek.",s:"Minimum viable task; jangan tangguh 48 jam."},
  24:{t:"Harta & Bumi",m:"Thawr; kekalkan aset.",s:"Dana kecemasan; automasi simpanan."},
  25:{t:"Kalam & Dagang",m:"Jawza; perhubungan.",s:"Pitch ringkas; 3 pelanggan sasaran."},
  26:{t:"Rahsia & Sirr",m:"Sartan; penjagaan batin.",s:"Privasi/infosec; jangan kongsi aib rumahtangga."},
  27:{t:"Kepimpinan",m:"Asad; syuhrah terkawal.",s:"Tonjol hasil, bukan diri; kongsikan kredit."},
  28:{t:"Khidmat Teliti",m:"Sumbulah; service & detail.",s:"Standard servis; ukur kepuasan pelanggan."},
  29:{t:"Keadilan Mizan",m:"Rundingan & kontrak.",s:"Semak kontrak & tarikh luput komitmen."},
  30:{t:"Aqrab Sirr",m:"Penutupan rahsia.",s:"Tutup majlis dengan doa kafarat; simpan adab."},
  31:{t:"Safar Ilmu",m:"Qaws; jaringan jauh.",s:"Belajar daripada mentor luar bidang."},
  32:{t:"Jambatan Zahir–Batin",m:"Ghaibiyyah awal.",s:"Seimbangkan ibadah-rumah-kerja; jaga janji."},
  33:{t:"Futuh Ilmu",m:"Musytari; keluasan baik.",s:"Ilmu → amalan; tulis nota ringkas 5-bullet."},
  34:{t:"Ujian Konflik",m:"Marikh; tegas beradab.",s:"Sejukkan dengan wudhu’; fakta > emosi."},
  35:{t:"Nur Nama",m:"Matahari; reputasi.",s:"Tolak pamer; jadikan teladan peribadi."},
  36:{t:"Kasih Penutup",m:"Zuhrah; damaikan ujung fasa.",s:"Restoratif: minta maaf/saling halalkan."},
  37:{t:"Kalam Amanah",m:"Utarid; tulis janji.",s:"Dokumen > cakap; audit perjanjian lama."},
  38:{t:"Cermin Hati",m:"Bulan; jaga tidur & rumah.",s:"Al-Baqarah; tidur berwudhu’; kurangkan skrin malam."},
  39:{t:"Nama Diuji",m:"Ghaibiyyah (28–45).",s:"Pilih diam bermakna; jaga janji & amanah."},
  40:{t:"Hijab Ego",m:"Api; kawal takabbur.",s:"Latih tawaduk; lebih mendengar."},
  41:{t:"Lintasan",m:"Angin; tapis bisikan.",s:"Dzikir pagi-petang; kurangkan pendedahan."},
  42:{t:"Serapan Emosi",m:"Air; empati bersempadan.",s:"Doa pelindung; ‘no’ yang beradab."},
  43:{t:"Amanah Tanah",m:"Tanggung stabil.",s:"Selesaikan kerja terbengkalai; kemaskan aset."},
  44:{t:"Sempitan Zuhal",m:"Tapisan darjat.",s:"Sabar tertib; tutup aib; kurangi pamer."},
  45:{t:"Futuh Musytari",m:"Luasan berkat.",s:"Syukur & agih manfaat; jangan lalai."},
  46:{t:"Warisan Ilmu",m:"Serah baton.",s:"Sediakan dokumentasi/ SOP pewarisan."},
  47:{t:"Warisan Harta",m:"Tertib faraid/hibah.",s:"Semak wasiat; elak pertikaian keluarga."},
  48:{t:"Warisan Jaringan",m:"Mentor–mente.",s:"Kenalkan pewaris kepada rangkaian penting."},
  49:{t:"Warisan Amal",m:"Tutup dengan ihsan.",s:"Tinggalkan amalan berterusan (jariah/ilmu)."},
  50:{t:"Audit Besar",m:"Hisab dunia.",s:"Senarai hutang–hutang budi; selesaikan."},
  51:{t:"Halalkan Hak",m:"Minta-maaf & redha.",s:"Telefon 1 orang/hari; baiki yang renggang."},
  52:{t:"Sapu Tertunggak",m:"Kemaskan fail/hutang.",s:"Zero-inbox; failkan dokumen; bayar yang kecil."},
  53:{t:"Sunnatullah",m:"Terima ketetapan.",s:"Redha & rancang semula; kitaran baharu menanti."},
  54:{t:"Khatimah Hasanah",m:"Penutup baik.",s:"Syukur; tutup majlis dengan doa; mulakan pusingan baharu."},
};

/** Nama buruj 1..12 (untuk ringkasan mod12) */
const BURUJ = ["Hamal","Thawr","Jawza","Sartan","Asad","Sumbulah","Mizan","Aqrab","Qaws","Jadi","Dalw","Hut"];

/** Komponen kecil */
const Box:React.FC<{alt?:boolean; children:any}> = ({alt,children})=>(
  <View style={{
    backgroundColor: alt? "#0e0a10" : "#14090b",
    borderRadius:12, padding:12, marginBottom:10,
    borderWidth:1, borderColor: alt? "#2b1233" : "#2a0e14"
  }}>{children}</View>
);
const Row:React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"})=>(
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#e8e6e3", opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

/** Adapter kad penuh */
const ArqamFullCard: ExplainAdapter = {
  id: "arqam-full",
  label: "Asrār al-Arqām — Rahsia Angka (1–54)",
  render(input: Input) {
    // Ambil angka dari kalkulator sedia ada
    const aDiri = input.aDiri||0;
    const aIbu  = input.aIbu||0;
    const aIsteri = input.aIsteri||0;
    const aAnak  = input.aAnakJumlah||0;
    const tawafiq = aDiri + aIbu + aIsteri + aAnak;

    const b30   = ((tawafiq % 30) || 30);
    const m12   = modWrap(tawafiq, 12);
    const m54   = modWrap(tawafiq, 54);

    const rec   = A[m54];
    const band  = BAND(m54);

    return (
      <Accordion title="Asrār al-Arqām — Rahsia Angka (Lengkap)">
        {/* Ringkasan angka */}
        <Box>
          <Row l="Jumlah Tawāfiq" r={tawafiq} c="#ff4d57"/>
          <Row l="Buruj (mod12)"  r={`${m12} — ${BURUJ[m12-1]}`}/>
          <Row l="Fasa (baki30)"  r={b30}/>
          <Row l="Angka (1–54)"  r={`${m54} — ${rec.t}`}/>
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Nilai diambil automatik dari kalkulator (jumlah huruf Jawi). Kadar 1–54 merujuk tradisi Shams al-Ma‘ārif — dipersembahkan secara nasihat/adab.
          </Text>
        </Box>

        {/* Fasa baki30 */}
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Fasa — Baki 30</Text>
          {b30<=10 && <Text style={{color:"#c9c6c2"}}>Pembukaan: bina momentum; kurangkan pendedahan; kekal tertib.</Text>}
          {b30>10 && b30<=20 && <Text style={{color:"#c9c6c2"}}>Ujian: tahan emosi; halalkan hak; utamakan keluarga.</Text>}
          {b30>20 && <Text style={{color:"#c9c6c2"}}>Penutupan: sapu hutang/isu tertunggak; muhasabah; susun semula.</Text>}
        </Box>

        {/* Buruj mod12 */}
        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Buruj — mod12</Text>
          <Text style={{color:"#c9c6c2"}}>{BURUJ[m12-1]}: gunakan kekuatan buruj untuk strategi & komunikasi; elak berlebihan sifat lawannya.</Text>
        </Box>

        {/* Angka 1–54 (maksud penuh) */}
        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Angka {m54} — {rec.t}</Text>
          <Text style={{color:"#e8e6e3"}}>{rec.m}</Text>
          <Text style={{color:"#c9c6c2", marginTop:6}}>{rec.s}</Text>
          <Text style={{color:"#9a9692", marginTop:8, fontSize:12}}>
            Jalur: {band.nama} — {band.maksud}
          </Text>
        </Box>

        {/* Panduan ringkas */}
        <Box alt>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:6}}>Panduan Ringkas</Text>
          <Text style={{color:"#c9c6c2"}}>• Selaraskan jadual dengan fasa (baki30).</Text>
          <Text style={{color:"#c9c6c2"}}>• Guna kekuatan buruj untuk strategi & komunikasi.</Text>
          <Text style={{color:"#c9c6c2"}}>• Angka 1–54: ikut fokus amali harian — tanpa unsur ritual/azimat.</Text>
        </Box>
      </Accordion>
    );
  }
};
export default ArqamFullCard;
