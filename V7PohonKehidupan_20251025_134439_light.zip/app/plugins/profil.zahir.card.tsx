import React from "react";
import { View, Text } from "react-native";
import Accordion from "../components/Accordion";
import type { ExplainAdapter, Input } from "../adapters/types";

// ---- Mini data set (zahir): unsur/planet/burj ----
const modWrap = (n:number, base:number) => ((Math.trunc(n)-1)%base+base)%base+1;

const UNSUR = [
  { k:1, n:"Api",   m:"Semangat tinggi & berdaya mula; kawal panas baran/ego, guna tenaga untuk pembaharuan." },
  { k:2, n:"Angin", m:"Idea pantas, komunikasi & dagang; latih konsisten supaya hasil terikat rapat." },
  { k:3, n:"Air",   m:"Empati, menyembuh, mudah menyesuaikan; jaga batas emosi & ketegasan." },
  { k:4, n:"Tanah", m:"Kukuh, praktikal, amanah; bina asas perlahan tetapi pasti, elak kaku." },
] as const;

const PLANET = [
  { k:1, n:"Zuhal",    m:"Ujian/pembersihan; sabar & tertib → darjat meningkat." },
  { k:2, n:"Musytari", m:"Melebar rezeki & ilmu; urus kelebihan dengan syukur." },
  { k:3, n:"Marikh",   m:"Tenaga pejuang; berani tapi elak tergesa & konflik sia-sia." },
  { k:4, n:"Matahari", m:"Kepimpinan/syuhrah; kawal pamer & ego." },
  { k:5, n:"Zuhrah",   m:"Kasih, seni & pendamaian; baik untuk hubungan & harmoni." },
  { k:6, n:"Utarid",   m:"Akal, tulisan & rundingan; rapi strategi & dokumentasi." },
  { k:7, n:"Bulan",    m:"Emosi & keluarga; stabilkan rutin tidur/rumah." },
] as const;

const BURJ = [
  { k:1,  n:"Hamal",    u:"Api",   m:"Pelopor berani; sesuai mula projek." },
  { k:2,  n:"Thawr",    u:"Tanah", m:"Memperkukuh harta; bina asas kukuh." },
  { k:3,  n:"Jawza",    u:"Angin", m:"Komunikasi & pembelajaran pantas." },
  { k:4,  n:"Sartan",   u:"Air",   m:"Keluarga/penjagaan; peka emosi." },
  { k:5,  n:"Asad",     u:"Api",   m:"Kepimpinan & syuhrah; elak angkuh." },
  { k:6,  n:"Sumbulah", u:"Tanah", m:"Tertib & khidmat; halus & teliti." },
  { k:7,  n:"Mizan",    u:"Angin", m:"Keadilan & keserasian; kuat diplomasi." },
  { k:8,  n:"Aqrab",    u:"Air",   m:"Rahsia, transformasi, kuasa batin." },
  { k:9,  n:"Qaws",     u:"Api",   m:"Safar, falsafah, visi jauh." },
  { k:10, n:"Jadi",     u:"Tanah", m:"Struktur & tanggungjawab." },
  { k:11, n:"Dalw",     u:"Angin", m:"Inovasi, komuniti, reformasi." },
  { k:12, n:"Hut",      u:"Air",   m:"Ilham, kasih & spiritual tinggi." },
] as const;

const bakiMaksud = (b:number)=>{
  const v = Math.trunc(b)||30;
  if (v>=1 && v<=10)  return "Fasa aktif: tenaga tinggi, peluang luas, gerak segera.";
  if (v>=11 && v<=20) return "Fasa ujian/penurunan: kawal emosi, rawat diri & perkemas rutin.";
  return "Fasa penutupan: rehat, muhasabah & ubah strategi sebelum kitaran baharu.";
};

const Box: React.FC<{children:any}> = ({children}) => (
  <View style={{backgroundColor:"#14090b", borderRadius:12, padding:12, marginBottom:10, borderWidth:1, borderColor:"#2a0e14"}}>
    {children}
  </View>
);
const Row: React.FC<{l:string; r:string|number; c?:string}> = ({l,r,c="#e8e6e3"}) => (
  <View style={{flexDirection:"row", justifyContent:"space-between", marginBottom:6}}>
    <Text style={{color:"#e8e6e3", opacity:.85}}>{l}</Text>
    <Text style={{color:c, fontWeight:"700"}}>{String(r)}</Text>
  </View>
);

/** PROFIL HAYAT (Zahir) — tumpu total abjad (tanpa bulan) */
const ProfilZahirCard: ExplainAdapter = {
  id: "profil-zahir",
  label: "Penjelasan — Profil Hayat (Zahir)",
  render(input: Input) {
    const aIsteri = input.aIsteri||0;
    const aAnak   = input.aAnakJumlah||0;
    const totalTawafiq = (input.aDiri||0)+(input.aIbu||0)+aIsteri+aAnak; // Zahir: hanya abjad

    const m4  = modWrap(totalTawafiq,4);
    const m7  = modWrap(totalTawafiq,7);
    const m12 = modWrap(totalTawafiq,12);
    const baki = (totalTawafiq % 30) || 30;

    const U = UNSUR.find(x=>x.k===m4)!;
    const P = PLANET.find(x=>x.k===m7)!;
    const B = BURJ.find(x=>x.k===m12)!;

    const nasihat = [
      `Unsur dominan: ${U.n} — ${U.m}`,
      `Planet naungan: ${P.n} — ${P.m}`,
      `Burj tabiat: ${B.n} (${B.u}) — ${B.m}`,
      `Baki 30: ${baki} — ${bakiMaksud(baki)}`,
    ];

    return (
      <Accordion title="Penjelasan — Profil Hayat (Zahir)">
        <Box>
          <Row l="Jumlah Abjad Diri"   r={input.aDiri||0} />
          <Row l="Jumlah Abjad Ibu"    r={input.aIbu||0} />
          <Row l="Jumlah Abjad Isteri" r={aIsteri} />
          <Row l="Jumlah Abjad Anak"   r={aAnak} />
          <Row l="Tawāfiq (Jumlah Abjad)" r={totalTawafiq} c="#ff4d57" />
          <Row l="Baki 30" r={baki} />
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:8}}>Kompas Unsur, Planet & Burj</Text>
          <Row l="Unsur"  r={U.n} />
          <Text style={{color:"#c9c6c2", marginBottom:8}}>{U.m}</Text>
          <Row l="Planet" r={P.n} />
          <Text style={{color:"#c9c6c2", marginBottom:8}}>{P.m}</Text>
          <Row l="Burj"   r={`${B.n} (${B.u})`} />
          <Text style={{color:"#c9c6c2"}}>{B.m}</Text>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:8}}>Fasa Baki 30</Text>
          <Text style={{color:"#e8e6e3"}}>
            {baki} — {bakiMaksud(baki)}
          </Text>
        </Box>

        <Box>
          <Text style={{color:"#e8e6e3", fontWeight:"800", marginBottom:8}}>Nasihat Zahir</Text>
          {nasihat.map((t, i)=>(
            <Text key={i} style={{color:"#c9c6c2", marginBottom:4}}>{`\u2022 ${t}`}</Text>
          ))}
          <Text style={{color:"#9a9692", marginTop:6, fontSize:12}}>
            Catatan: Profil Zahir menilai kecenderungan lahir berdasarkan jumlah abjad; faktor bulan/kalbu tidak dipakai di sini.
          </Text>
        </Box>
      </Accordion>
    );
  }
};
export default ProfilZahirCard;
