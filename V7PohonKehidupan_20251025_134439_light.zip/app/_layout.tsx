import React from "react";
import { View, StyleSheet, SafeAreaView } from "react-native";
import { Stack } from "expo-router";
import ForensikHeader from "./components/ForensikHeader";
import VideoSlider from "./components/VideoSlider";

/**
 * RootLayout dibalut dalam SafeAreaView + Frame merah gelap.
 * - Frame: margin 12/10 dari tepi skrin (tak cecah dinding/kepala/lantai)
 * - Inner shadow: vignette halus, tak sentuh interaksi (pointerEvents="none")
 * - Konten asal dikekalkan 1:1 (Header, VideoSlider, Stack)
 */
export default function RootLayout() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#000" }}>
      <View style={styles.frame}>
        <View style={styles.innerVignette} pointerEvents="none" />
        {/* === Konten asal bermula === */}
        <ForensikHeader />
        <VideoSlider
          title="Koleksi Video"
          videos={[
            "https://youtu.be/Acz3DmsGniY?si=MlzCmsdYDWoqtb-s",
            "https://youtu.be/AeTt9aEzxxg?si=3WPdMsHCbsmLZOAv",
            "https://youtu.be/zG8-TVjbCxw?si=1dQt3VUPP4mZXG5h"
          ]}
        />
        <Stack screenOptions={{ headerShown: false }} />
        {/* === Konten asal tamat === */}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  // Warna latar asal (hijau gelap) dikekalkan untuk rujukan / keserasian
  container: {
    flex: 1,
    backgroundColor: "#001a0f", // hijau gelap hampir hitam
  },

  // Frame merah gelap tanpa makan content dalaman
  frame: {
    elevation: 10,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 12,
    shadowOpacity: 0.25,
    shadowColor: "#ff3344",
    overflow: "hidden",
    borderColor: "#3a0f16",
    borderWidth: 2,
    borderRadius: 16,
    marginVertical: 10,
    marginHorizontal: 12,
    backgroundColor: "#170406",
    flex: 1,
    marginHorizontal: 12,
    marginVertical: 10,
    borderRadius: 16,
    backgroundColor: "#170406",     // merah gelap
    borderWidth: 1,
    borderColor: "#3a0f16",         // garis merah pekat
    overflow: "hidden",
  },

  // Inner shadow (vignette) — kelihatan seperti shadow ke dalam
  innerVignette: {
    position: "absolute",
    top: 0, left: 0, right: 0, bottom: 0,
    borderRadius: 16,
    borderTopWidth: 10,
    borderRightWidth: 10,
    borderBottomWidth: 10,
    borderLeftWidth: 10,
    borderColor: "rgba(0,0,0,0.28)",
  },
});
