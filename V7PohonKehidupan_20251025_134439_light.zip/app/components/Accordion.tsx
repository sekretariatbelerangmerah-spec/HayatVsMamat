import React, { useState } from "react";
import { View, Text, TouchableOpacity, LayoutAnimation, StyleSheet } from "react-native";

type Props = {
  title: string;
  children?: React.ReactNode;
};

export default function Accordion({ title, children }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          setOpen(!open);
        }}
        style={[styles.header, { backgroundColor: open ? "#1a2d23" : "#143d2a" }]}
      >
        <Text style={styles.title}>
          {open ? "• " : "+"} {title}
        </Text>
      </TouchableOpacity>

      {open && <View style={styles.content}>{children}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: "#244a35",
    borderRadius: 8,
    marginBottom: 8,
    overflow: "hidden",
  },
  header: {
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  title: {
    color: "#dfeee4",
    fontWeight: "700",
  },
  content: {
    padding: 10,
    backgroundColor: "#0e2219",
  },
});
