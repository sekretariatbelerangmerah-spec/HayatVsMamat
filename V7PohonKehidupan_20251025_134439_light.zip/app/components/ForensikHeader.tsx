import React from "react";
import { View, Text, StyleSheet, Platform } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import BMLogo from "./BMLogo";

type Props = {
  compact?: boolean;
  title1?: string;
  title2?: string;
  title3?: string;
};

export default function ForensikHeader({
  compact = false,
  title1 = "Ensiklopedia Kehidupan",
  title2 = "Sains Purba Belerang Merah",
  title3 = "Ali Taqiuddin & Nurul Falah (Malika World Publishing)",
}: Props) {
  return (
    <SafeAreaView edges={["top"]} style={styles.safe}>
      <LinearGradient
        colors={["#0C1C3D", "#10315C", "#1A4B73", "#F4C96B"]}
        locations={[0, 0.45, 0.75, 1]}
        start={[0, 0]}
        end={[1, 1]}
        style={styles.wrap}
      >
        <View style={styles.glow} />
        <View style={styles.bar}>
          <View style={styles.logoWrap}>
            <BMLogo size={28} />
          </View>
          <View style={styles.texts}>
            <Text style={styles.title1} numberOfLines={1}>{title1}</Text>
            <Text style={styles.title2} numberOfLines={1}>{title2}</Text>
            <Text style={styles.title3} numberOfLines={2} ellipsizeMode="tail">
              {title3}
            </Text>
          </View>
        </View>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { backgroundColor: "transparent" },
  wrap: {
    paddingHorizontal: 10,
    paddingBottom: 5,
    paddingTop: 4,
    borderBottomWidth: 0,
  },
  glow: {
    position: "absolute",
    left: 8,
    right: 8,
    top: Platform.select({ ios: 6, android: 8, default: 6 }),
    height: 45,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.05)",
    shadowColor: "#00FFFF",
    shadowOpacity: 0.4,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 0 },
    ...Platform.select({ android: { elevation: 0 } }),
  },
  bar: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(255,255,255,0.05)",
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.1)",
  },
  logoWrap: {
    width: 30,
    height: 30,
    borderRadius: 8,
    overflow: "hidden",
  },
  texts: { flex: 1 },
  title1: {
    color: "#EFFFFF",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 0.2,
    textShadowColor: "#6CE6FF",
    textShadowRadius: 6,
  },
  title2: {
    color: "#FFD98A",
    fontSize: 8.5,
    fontWeight: "700",
    letterSpacing: 0.2,
    textShadowColor: "#FFD463",
    textShadowRadius: 5,
  },
  title3: {
    color: "rgba(255,255,255,0.85)",
    fontSize: 7,
    fontWeight: "500",
    letterSpacing: 0.1,
    marginTop: 2,
    flexShrink: 1,
    textShadowColor: "rgba(0,255,255,0.25)",
    textShadowRadius: 3,
  },
});
