import React, { useRef, useState, useCallback, useEffect } from "react";
import {
  View, Text, StyleSheet, Image, TouchableOpacity,
  Dimensions, Modal, ActivityIndicator, FlatList
} from "react-native";
import { WebView } from "react-native-webview";
import { extractYouTubeId, ytThumb } from "../lib/youtube";

/**
 * Single item per page:
 * - Setiap PAGE = lebar skrin (pageW)
 * - Kad kecil 35% skrin diletak di tengah page
 * - Auto-slide 2s
 */
export default function VideoSlider({ videos, title = "Koleksi Video" }) {
  const [open, setOpen] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const width = Dimensions.get("window").width;
  const pageW = Math.round(width);              // lebar satu page (paksa 1 item)
  const cardW = Math.min(pageW * 0.35, 240);    // saiz kad kecil (35% skrin)
  const cardH = Math.round(cardW * 9 / 16);

  const data = (videos || [])
    .map((url: string) => ({ id: extractYouTubeId(url), url }))
    .filter((x) => x.id) as { id: string; url: string }[];

  const listRef = useRef<FlatList<any>>(null);
  const [index, setIndex] = useState(0);

  // Auto-slide setiap 2s
  useEffect(() => {
    if (data.length <= 1) return;
    const t = setInterval(() => {
      const n = (index + 1) % data.length;
      try {
        listRef.current?.scrollToIndex({ index: n, animated: true, viewPosition: 0 });
      } catch {
        listRef.current?.scrollToOffset({ offset: n * pageW, animated: true });
      }
      setIndex(n);
    }, 2000);
    return () => clearInterval(t);
  }, [index, data.length, pageW]);

  const onViewableItemsChanged = useCallback(({ viewableItems }: any) => {
    if (viewableItems?.length) {
      const i = viewableItems[0].index ?? 0;
      if (Number.isFinite(i)) setIndex(i);
    }
  }, []);
  const viewConfig = { viewAreaCoveragePercentThreshold: 60 };

  const renderItem = ({ item }: { item: { id: string; url: string } }) => (
    <View style={{ width: pageW, alignItems: "center" }}>
      <TouchableOpacity
        activeOpacity={0.9}
        style={[s.card, { width: cardW, height: cardH }]}
        onPress={() => setOpen(item.id)}
      >
        <Image source={{ uri: ytThumb(item.id) }} style={s.thumb} />
        <View style={s.play}><View style={s.triangle} /></View>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={s.block}>
      {!!title && <Text style={s.title}>{title}</Text>}

      <FlatList
        ref={listRef}
        data={data}
        renderItem={renderItem}
        keyExtractor={(it) => it.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={pageW}                // penting: 1 page = 1 lebar skrin
        snapToAlignment="start"
        getItemLayout={(_, i) => ({ length: pageW, offset: pageW * i, index: i })}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewConfig}
        // Pastikan tiada padding / separator yang boleh muatkan lebih dari 1 item
        contentContainerStyle={{}}
      />

      <View style={s.dots}>
        {data.map((_, i) => (
          <View
            key={i}
            style={[s.dot, { opacity: i === index ? 1 : 0.35, width: i === index ? 10 : 6 }]}
          />
        ))}
      </View>

      <Modal visible={!!open} animationType="fade" onRequestClose={() => setOpen(null)}>
        <View style={s.modalRoot}>
          {open && (
            <WebView
              source={{ uri: `https://www.youtube.com/embed/${open}?playsinline=1&rel=0&autoplay=1` }}
              onLoadStart={() => setLoading(true)}
              onLoadEnd={() => setLoading(false)}
              allowsFullscreenVideo
              allowsInlineMediaPlayback
              mediaPlaybackRequiresUserAction={false}
              javaScriptEnabled
              domStorageEnabled
              style={{ flex: 1 }}
            />
          )}
          {loading && <ActivityIndicator style={s.loader} size="large" color="#fff" />}
          <TouchableOpacity onPress={() => setOpen(null)} style={s.closeBtn}>
            <Text style={s.closeText}>Tutup</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  block: { marginTop: 6, gap: 6 },
  title: { color: "#EFFFFF", fontSize: 11, fontWeight: "700", paddingLeft: 4 },
  card: { borderRadius: 10, overflow: "hidden", backgroundColor: "transparent" },
  thumb: { width: "100%", height: "100%" },
  play: {
    position: "absolute", left: "50%", top: "50%",
    width: 22, height: 22, marginLeft: -11, marginTop: -11,
    borderRadius: 11, backgroundColor: "rgba(0,0,0,0.45)",
    alignItems: "center", justifyContent: "center",
  },
  triangle: {
    width: 0, height: 0, borderLeftWidth: 7,
    borderTopWidth: 5, borderBottomWidth: 5,
    borderLeftColor: "#fff",
    borderTopColor: "transparent",
    borderBottomColor: "transparent",
    marginLeft: 2,
  },
  dots: { flexDirection: "row", justifyContent: "center", marginTop: 6, gap: 6 },
  dot: { height: 4, borderRadius: 3, backgroundColor: "#c8ffe6" },
  modalRoot: { flex: 1, backgroundColor: "#000" },
  loader: { position: "absolute", top: "50%", left: "50%", marginLeft: -20, marginTop: -20 },
  closeBtn: { position: "absolute", top: 40, right: 20, backgroundColor: "rgba(255,255,255,0.1)", paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  closeText: { color: "#fff" },
});
