import NoopCard from "../plugins/_stubs/noop.card";
import type { ExplainAdapter, BoardAdapter } from "./types";
import CardHariLemahKuat from "../plugins/profil.hari.lemah.kuat.card";
import CardAjalStandalone from "../plugins/board.ajal.standalone.card";
import CardTawafidhZawjiyyah from "../plugins/profil.tawafidh.zawjiyyah.card";
import CardPedomanAlbuni from "../plugins/pedoman.albuni.card";
import CardNasabUmmahat from "../plugins/profil.nasab.ummahat.card";
import HurufNuqatah from "../plugins/huruf.nuqatah.card";
import HurufPosisiDetail from "../plugins/huruf.posisi.detail.card";
import ProfilBurujCard from "../plugins/profil.buruj.card";
import ArqamFullCard from "../plugins/profil.arqam.full.card";
import ProfilAsmaCard from "../plugins/profil.asma.card";
import ProfilKeluargaResonans from "../plugins/profil.keluarga.resonans";
import ProfilWiqayahCard from "../plugins/profil.wiqayah.card";
import ProfilPlanetaryHoursCard from "../plugins/profil.planetary-hours.card";
import ProfilMizajCard from "../plugins/profil.mizaj.card";
import ProfilGhaibCard from "../plugins/profil.ghaib.card";
import ProfilBatinCard from "../plugins/profil.batin.card";
import ProfilZahirCard from "../plugins/profil.zahir.card";
import CardHayatMamat from "../plugins/profil.hayat.mamat.card";
import CardPedomanHarian from "../plugins/pedoman.harian.card";

// Order matters (rendering order)
export const ExplainAdapters: ExplainAdapter[] = [
  CardHariLemahKuat,
  CardHayatMamat,
  CardPedomanAlbuni,
  CardPedomanHarian,
  CardAjalStandalone,
  CardTawafidhZawjiyyah,
  CardNasabUmmahat,
  HurufNuqatah,
  HurufPosisiDetail,
  ProfilBurujCard,
  ArqamFullCard,
  ProfilAsmaCard,
  ProfilKeluargaResonans,
  ProfilWiqayahCard,
  ProfilPlanetaryHoursCard,
  ProfilMizajCard,
  ProfilGhaibCard,
  ProfilBatinCard,
  ProfilZahirCard,
];
